package com.vision.ems.model;

public class EmployeeDetails {

	private int employee_id;
	private String name;
	private String designation;
	private String address;
	private String department;
	private double salary;
	public int getemployee_id() {
		return employee_id;
	}
	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		salary = salary;
	}
	
	@Override
	public String toString() {
		return "Employee_Details [employee_id=" + employee_id + ", name=" + name + ", designation=" + designation + ", address="
				+ address + ", department=" + department + ", Salary=" + salary + "]";
	}
	
}
