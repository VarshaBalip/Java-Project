package com.vision.ems.service1;

import java.io.IOException;
import java.sql.SQLException;

public interface EmployeeService {
	void CreateEmployeeTable() throws ClassNotFoundException, SQLException;
	void AddNewEmployeeDetails()throws ClassNotFoundException, SQLException, NumberFormatException, IOException;
	void ShowSingleEmployeeDetails()throws ClassNotFoundException, SQLException, NumberFormatException, IOException;
	void ShowAllEmployeeDetails()throws ClassNotFoundException, SQLException, NumberFormatException, IOException;
	void UpdateEmployeeDetails()throws ClassNotFoundException, SQLException, NumberFormatException, IOException;
	void DeleteEmployeeDetails()throws ClassNotFoundException, SQLException, NumberFormatException, IOException;
}
