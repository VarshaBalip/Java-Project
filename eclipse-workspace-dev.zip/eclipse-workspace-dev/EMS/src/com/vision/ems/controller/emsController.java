package com.vision.ems.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.vision.ems.model.EmployeeDetails;
import com.vision.ems.service1.EmployeeService;
import com.vision.ems.serviceImplementation.EmployeeServiceImplementation;

public class emsController {
 
	public static void main(String[] args) throws ClassNotFoundException, SQLException, NumberFormatException, IOException {

		EmployeeService employeeService =  new EmployeeServiceImplementation();
		Scanner sc = new Scanner(System.in);

	    boolean exit = false;
	    while (!exit) 
	    {
			System.out.println("Press 1 : Create table Employee");
			System.out.println("Press 2 : Insert data into table Employee");
			System.out.println("Press 3 : View current Employee");
			System.out.println("Press 4 : View all Employee");
			System.out.println("Press 5 : Update Employee");
			System.out.println("Press 6 : Delete Employee");
			System.out.println("Press 0 : Exit");
			
			int choice = sc.nextInt();
			
	        switch (choice) {
	        case 1:
	        	employeeService.CreateEmployeeTable();
	    		System.out.println("\nDo you want to perform any operation again? Type Yes / No");
	            if (sc.next().equalsIgnoreCase("no"))
	                    exit = true;
	                break;
	        case 2:
	        	employeeService.AddNewEmployeeDetails();
	    		System.out.println("\nDo you want to perform any operation again? Type Yes / No");
	            if (sc.next().equalsIgnoreCase("no"))
	                    exit = true;
	                break;
	        case 3:
	        	employeeService.ShowSingleEmployeeDetails();
	    		System.out.println("\nDo you want to perform any operation again? Type Yes / No");
	            if (sc.next().equalsIgnoreCase("no"))
	                    exit = true;
	                break;
	        case 4:
	        	employeeService.ShowAllEmployeeDetails();
	    		System.out.println("\nDo you want to perform any operation again? Type Yes / No");
	            if (sc.next().equalsIgnoreCase("no"))
	                    exit = true;
	                break;
	        case 5:
	        	employeeService.UpdateEmployeeDetails();
	    		System.out.println("\nDo you want to perform any operation again? Type Yes / No");
	            if (sc.next().equalsIgnoreCase("no"))
	                    exit = true;
	                break;
	        case 6:
	        	employeeService.DeleteEmployeeDetails();
	    		System.out.println("\nDo you want to perform any operation again? Type Yes / No");
	            if (sc.next().equalsIgnoreCase("no"))
	                    exit = true;
	                break;
	        case 0:
	        	exit = true;
	        	System.out.println("Program is terminated");
	            break;
	        default:
	            break;
	        }
	    }   
    }
}
