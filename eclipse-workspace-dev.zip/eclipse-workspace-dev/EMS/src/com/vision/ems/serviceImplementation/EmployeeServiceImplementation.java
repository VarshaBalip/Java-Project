package com.vision.ems.serviceImplementation;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.text.html.HTMLDocument.HTMLReader.PreAction;

import com.vision.ems.service1.EmployeeService;

public class EmployeeServiceImplementation implements EmployeeService{
	
	public void CreateEmployeeTable() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sonu_solutions","root","Vision@2023");
		Statement statement = connection.createStatement();	
		if (tableExists(connection,"Employee")==false)
		{ 
			String sql = "create table Employee(employee_id int primary key, name varchar(40), designation varchar(40), address varchar(100), department varchar(20), salary double)";
			statement.execute(sql);
			System.out.println("Table created successfully");
		}
		else
		{
			System.out.println("Table already exist");
		}
	}

	public void AddNewEmployeeDetails() throws ClassNotFoundException, SQLException, NumberFormatException, IOException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sonu_solutions","root","Vision@2023");
		
		String sql = "Insert into Employee Values(?,?,?,?,?,?)";
		PreparedStatement  statement = connection.prepareStatement(sql);	

		BufferedReader bufferReader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Employee ID");
	    int EmployeeID = Integer.parseInt(bufferReader.readLine());
		statement.setInt(1, EmployeeID);
		
		System.out.println("Enter Employee Name");
	    String EmployeeName = bufferReader.readLine();
		statement.setString(2, EmployeeName);

		System.out.println("Enter Employee Designation");
	    String EmployeeDesignation = bufferReader.readLine();
		statement.setString(3, EmployeeDesignation);

		System.out.println("Enter Employee Address");
	    String EmployeeAddress = bufferReader.readLine();
		statement.setString(4, EmployeeAddress);

		System.out.println("Enter Employee Department");
	    String EmployeeDepartment = bufferReader.readLine();
		statement.setString(5, EmployeeDepartment);

		System.out.println("Enter Employee Salary");
	    double EmployeeSalary = Double.parseDouble(bufferReader.readLine());
		statement.setDouble(6,EmployeeSalary);
		
		statement.executeUpdate();
		
		System.out.println("Record inserted successfully");
		connection.close();
	}

	public void ShowSingleEmployeeDetails() throws ClassNotFoundException, SQLException, NumberFormatException, IOException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sonu_solutions","root","Vision@2023");
		Statement statement = connection.createStatement();	

		BufferedReader bufferReader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Employee ID");
	    int EmployeeID = Integer.parseInt(bufferReader.readLine());
	    
		String sql = "Select * from Employee where employee_id = " + EmployeeID;
		
		ResultSet rs = statement.executeQuery(sql);
		
	      while (rs.next()) {
	    	int employee_id = rs.getInt("employee_id");
	        String employeename = rs.getString("name");
	        String employeedesignation = rs.getString("designation");
	        String employeeaddress = rs.getString("address");
	        String employeedepartment = rs.getString("department");
	        double employeesalary = rs.getDouble("salary");
	        System.out.println("\nBelow is the record for Employee ID=" + EmployeeID);
	        System.out.println(employee_id + ", " + employeename + ", " + employeedesignation +
	                           ", " + employeeaddress + ", " + employeedepartment + ", " + employeesalary);
	      }
	}

	public void ShowAllEmployeeDetails() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sonu_solutions","root","Vision@2023");
		Statement statement = connection.createStatement();	
		
		String sql = "Select * from Employee";
				
		ResultSet rs = statement.executeQuery(sql);
		System.out.println("\nEmployee_id\t\tname\t\tdesignation\t\taddress\t\tdepartment\t\tsalary");
		while (rs.next()) {

	    	int employee_id = rs.getInt("employee_id");
	        String employeename = rs.getString("name");
	        String employeedesignation = rs.getString("designation");
	        String employeeaddress = rs.getString("address");
	        String employeedepartment = rs.getString("department");
	        double employeesalary = rs.getDouble("salary");

	        System.out.println(employee_id + "\t\t" + employeename + "\t\t" + employeedesignation + "\t\t" + employeeaddress + "\t\t" + employeedepartment + "\t\t" + employeesalary);
        }

			
	}

	public void UpdateEmployeeDetails() throws ClassNotFoundException, SQLException, NumberFormatException, IOException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sonu_solutions","root","Vision@2023");
		Statement statement = connection.createStatement();	
		String sql;
		
		BufferedReader bufferReader = new BufferedReader(new InputStreamReader(System.in));

	    boolean exit = false;
	    while (!exit) 
	    {
			System.out.println("\nEnter Employee ID which you want to update");
		    int EmployeeID = Integer.parseInt(bufferReader.readLine());

	    	System.out.println("Press 1 : Update Employee : Name");
			System.out.println("Press 2 : Update Employee : Designation");
			System.out.println("Press 3 : Update Employee : Address");
			System.out.println("Press 4 : Update Employee : Department");
			System.out.println("Press 5 : Update Employee : Salary");
			System.out.println("Press 0 : Exit");
			
		    int choice = Integer.parseInt(bufferReader.readLine());
            Scanner sc1 = new Scanner(System.in);

			switch (choice) {
	        
			case 1:
	    		String employeename = bufferReader.readLine();
	        	sql = "Update Employee set name='" + employeename + "' where Employee_Id="+ EmployeeID;
	    		statement.execute(sql);
	    		System.out.println("Name Updated Successfully");
	    		
	    		System.out.println("\nDo you want to continue? Type Yes / No");
	            if (sc1.next().equalsIgnoreCase("no"))
	                    exit = true;
	                break;
	        case 2:
	    		String employeedesignation  = bufferReader.readLine();
	        	sql = "Update Employee set designation='" + employeedesignation  + "' where Employee_Id="+ EmployeeID;
	    		statement.execute(sql);
	    		
	    		System.out.println("Designation Updated Successfully");
	    		System.out.println("\nDo you want to continue? Type Yes / No");
	    		
	            if (sc1.next().equalsIgnoreCase("no"))
	                    exit = true;
	                break;
	        case 3:
	    		String employeeaddress  = bufferReader.readLine();
	        	sql = "Update Employee set address='" + employeeaddress  + "' where Employee_Id="+ EmployeeID;
	    		statement.execute(sql);
	    		
	    		System.out.println("Address Updated Successfully");
	    		System.out.println("\nDo you want to continue? Type Yes / No");

	    		if (sc1.next().equalsIgnoreCase("no"))
	                    exit = true;
	                break;
	        case 4:
	    		String employeedepartment  = bufferReader.readLine();
	        	sql = "Update Employee set department='" + employeedepartment  + "' where Employee_Id="+ EmployeeID;
	    		statement.execute(sql);
	    		
	    		System.out.println("Department Updated Successfully");
	    		System.out.println("\nDo you want to continue? Type Yes / No");
	    		
	            if (sc1.next().equalsIgnoreCase("no"))
	                    exit = true;
	                break;
	        case 5:
	        	double employeesalary = Double.parseDouble(bufferReader.readLine());
	        	sql = "Update Employee set salary=" + employeesalary + " where Employee_Id="+ EmployeeID;
	    		statement.execute(sql);
	    		
	    		System.out.println("Salary Updated Successfully");
	    		System.out.println("\nDo you want to continue? Type Yes / No");
	    		
	            if (sc1.next().equalsIgnoreCase("no"))
	                    exit = true;
	                break;
	        case 0:
	        	exit = true;
	        	System.out.println("Program Terminated");
	            break;
	        default :
	            break;
	        }
	    }

	}

	public void DeleteEmployeeDetails() throws ClassNotFoundException, SQLException, NumberFormatException, IOException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sonu_solutions","root","Vision@2023");
		Statement statement = connection.createStatement();	

		BufferedReader bufferReader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Press 1 : Enter Employee ID which you want to delete");
	    int EmployeeID = Integer.parseInt(bufferReader.readLine());
		
		String sql = "Delete from Employee  where Employee_Id =" + EmployeeID;
		statement.execute(sql);
		System.out.println("Employee deleted Successfully");
	}

	static boolean tableExists(Connection  connection, String tableName) throws SQLException {
	    DatabaseMetaData meta = connection.getMetaData();
	    ResultSet resultSet = meta.getTables(null, null, tableName, new String[] {"TABLE"});

	    return resultSet.next();
	}

}
