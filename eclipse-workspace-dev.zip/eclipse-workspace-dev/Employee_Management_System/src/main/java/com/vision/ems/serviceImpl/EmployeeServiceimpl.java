package com.vision.ems.serviceImpl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.text.html.HTMLDocument.HTMLReader.PreAction;

import com.vision.ems.serviceI.EmployeeService;

public class EmployeeServiceimpl implements EmployeeService{
	
	public void createEmployeeTable() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sonu_solutions","root","Vision@2023");
		Statement statement = connection.createStatement();	
		if (tableExists(connection,"Employee")==false)
		{ 
			String sql = "create table Employee(emp_id int primary key, name varchar(40), designation varchar(40), address varchar(100), department varchar(20), salary double)";
			statement.execute(sql);
			System.out.println("Table created Successfully");
		}
		else
		{
			System.out.println("Table already exist");
		}
	}

	public void addNewEmployeeDetails() throws ClassNotFoundException, SQLException, NumberFormatException, IOException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sonu_solutions","root","Vision@2023");
		
		String sql = "Insert into Employee Values(?,?,?,?,?,?)";
		PreparedStatement  statement = connection.prepareStatement(sql);	

		BufferedReader bufferReader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter employee ID");
	    int empID = Integer.parseInt(bufferReader.readLine());
		statement.setInt(1, empID);
		
		System.out.println("Enter employee name");
	    String empname = bufferReader.readLine();
		statement.setString(2, empname);

		System.out.println("Enter employee designation");
	    String empdesig = bufferReader.readLine();
		statement.setString(3, empdesig);

		System.out.println("Enter employee address");
	    String empaddress = bufferReader.readLine();
		statement.setString(4, empaddress);

		System.out.println("Enter employee department");
	    String empdepart = bufferReader.readLine();
		statement.setString(5, empdepart);

		System.out.println("Enter employee salary");
	    double empsal = Double.parseDouble(bufferReader.readLine());
		statement.setDouble(6,empsal);
		
		statement.executeUpdate();
		
		System.out.println("Record inserted successfully");
		connection.close();
	}

	public void showSinleEmployeeDetails() throws ClassNotFoundException, SQLException, NumberFormatException, IOException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sonu_solutions","root","Vision@2023");
		Statement statement = connection.createStatement();	

		BufferedReader bufferReader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter employee ID");
	    int empID = Integer.parseInt(bufferReader.readLine());
	    
		String sql = "Select * from Employee where emp_id = " + empID;
		
		ResultSet rs = statement.executeQuery(sql);
		
	      while (rs.next()) {
	    	int emp_ID = rs.getInt("emp_id");
	        String empname = rs.getString("name");
	        String empdesig = rs.getString("designation");
	        String empaddress = rs.getString("address");
	        String empdepart = rs.getString("department");
	        double empsal = rs.getDouble("salary");
	        System.out.println("\nBelow is the record for Employee id=" + empID);
	        System.out.println(emp_ID + ", " + empname + ", " + empdesig +
	                           ", " + empaddress + ", " + empdepart + ", " + empsal);
	      }
	}

	public void showAllEmployeeDetails() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sonu_solutions","root","Vision@2023");
		Statement statement = connection.createStatement();	
		
		String sql = "Select * from Employee";
				
		ResultSet rs = statement.executeQuery(sql);
		System.out.println("\nEmp_id\t\tname\t\tdesignation\t\taddress\t\tdepartment\t\tsalary");
		while (rs.next()) {

	    	int emp_ID = rs.getInt("emp_id");
	        String empname = rs.getString("name");
	        String empdesig = rs.getString("designation");
	        String empaddress = rs.getString("address");
	        String empdepart = rs.getString("department");
	        double empsal = rs.getDouble("salary");

	        System.out.println(emp_ID + "\t\t" + empname + "\t\t" + empdesig + "\t\t" + empaddress + "\t\t" + empdepart + "\t\t" + empsal);
        }

			
	}

	public void updateEmployeeDetails() throws ClassNotFoundException, SQLException, NumberFormatException, IOException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sonu_solutions","root","Vision@2023");
		Statement statement = connection.createStatement();	
		String sql;
		
		BufferedReader bufferReader = new BufferedReader(new InputStreamReader(System.in));

	    boolean exit = false;
	    while (!exit) 
	    {
			System.out.println("\nEnter employee id want to update");
		    int empID = Integer.parseInt(bufferReader.readLine());

	    	System.out.println("Press 1 : Update Employee : Name");
			System.out.println("Press 2 : Update Employee : Designation");
			System.out.println("Press 3 : Update Employee : Address");
			System.out.println("Press 4 : Update Employee : Department");
			System.out.println("Press 5 : Update Employee : Salary");
			System.out.println("Press 0 : Exit");
			
		    int choice = Integer.parseInt(bufferReader.readLine());
            Scanner sc1 = new Scanner(System.in);

			switch (choice) {
	        
			case 1:
	    		String empname = bufferReader.readLine();
	        	sql = "Update Employee set name='" + empname + "' where emp_Id="+ empID;
	    		statement.execute(sql);
	    		System.out.println("Name Updated Successfully");
	    		
	    		System.out.println("\nDo you want to continue? Type Yes / No");
	            if (sc1.next().equalsIgnoreCase("no"))
	                    exit = true;
	                break;
	        case 2:
	    		String empdesig = bufferReader.readLine();
	        	sql = "Update Employee set designation='" + empdesig + "' where emp_Id="+ empID;
	    		statement.execute(sql);
	    		
	    		System.out.println("Designation Updated Successfully");
	    		System.out.println("\nDo you want to continue? Type Yes / No");
	    		
	            if (sc1.next().equalsIgnoreCase("no"))
	                    exit = true;
	                break;
	        case 3:
	    		String empaddress = bufferReader.readLine();
	        	sql = "Update Employee set address='" + empaddress + "' where emp_Id="+ empID;
	    		statement.execute(sql);
	    		
	    		System.out.println("Address Updated Successfully");
	    		System.out.println("\nDo you want to continue? Type Yes / No");

	    		if (sc1.next().equalsIgnoreCase("no"))
	                    exit = true;
	                break;
	        case 4:
	    		String empdepart = bufferReader.readLine();
	        	sql = "Update Employee set department='" + empdepart + "' where emp_Id="+ empID;
	    		statement.execute(sql);
	    		
	    		System.out.println("Department Updated Successfully");
	    		System.out.println("\nDo you want to continue? Type Yes / No");
	    		
	            if (sc1.next().equalsIgnoreCase("no"))
	                    exit = true;
	                break;
	        case 5:
	        	double empsal = Double.parseDouble(bufferReader.readLine());
	        	sql = "Update Employee set salary=" + empsal + " where emp_Id="+ empID;
	    		statement.execute(sql);
	    		
	    		System.out.println("Salary Updated Successfully");
	    		System.out.println("\nDo you want to continue? Type Yes / No");
	    		
	            if (sc1.next().equalsIgnoreCase("no"))
	                    exit = true;
	                break;
	        case 0:
	        	exit = true;
	        	System.out.println("Program Terminated");
	            break;
	        default :
	            break;
	        }
	    }

	}

	public void deleteEmployeeDetails() throws ClassNotFoundException, SQLException, NumberFormatException, IOException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sonu_solutions","root","Vision@2023");
		Statement statement = connection.createStatement();	

		BufferedReader bufferReader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Press 1 : Enter employee id want to delete");
	    int empID = Integer.parseInt(bufferReader.readLine());
		
		String sql = "Delete from Employee  where emp_id =" + empID;
		statement.execute(sql);
		System.out.println("Employee deleted Successfully");
	}

	static boolean tableExists(Connection  connection, String tableName) throws SQLException {
	    DatabaseMetaData meta = connection.getMetaData();
	    ResultSet resultSet = meta.getTables(null, null, tableName, new String[] {"TABLE"});

	    return resultSet.next();
	}

}
