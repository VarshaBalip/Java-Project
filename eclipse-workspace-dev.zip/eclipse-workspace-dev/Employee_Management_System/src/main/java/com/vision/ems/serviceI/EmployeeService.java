package com.vision.ems.serviceI;

import java.io.IOException;
import java.sql.SQLException;

public interface EmployeeService {
	void createEmployeeTable() throws ClassNotFoundException, SQLException;
	void addNewEmployeeDetails()throws ClassNotFoundException, SQLException, NumberFormatException, IOException;
	void showSinleEmployeeDetails()throws ClassNotFoundException, SQLException, NumberFormatException, IOException;
	void showAllEmployeeDetails()throws ClassNotFoundException, SQLException, NumberFormatException, IOException;
	void updateEmployeeDetails()throws ClassNotFoundException, SQLException, NumberFormatException, IOException;
	void deleteEmployeeDetails()throws ClassNotFoundException, SQLException, NumberFormatException, IOException;
}
