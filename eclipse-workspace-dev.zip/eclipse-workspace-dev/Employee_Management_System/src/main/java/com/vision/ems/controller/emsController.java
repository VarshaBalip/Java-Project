package com.vision.ems.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.vision.ems.model.EmployeeDetails;
import com.vision.ems.serviceI.EmployeeService;
import com.vision.ems.serviceImpl.EmployeeServiceimpl;

public class emsController {

	public static void main(String[] args) throws ClassNotFoundException, SQLException, NumberFormatException, IOException {

		EmployeeService employeeService =  new EmployeeServiceimpl();
		Scanner sc = new Scanner(System.in);

	    boolean exit = false;
	    while (!exit) 
	    {
			System.out.println("Press 1 : Create table Employee");
			System.out.println("Press 2 : Insert data into table Employee");
			System.out.println("Press 3 : View Current Employee");
			System.out.println("Press 4 : View All Employee");
			System.out.println("Press 5 : Update Employee");
			System.out.println("Press 6 : Delete Employee");
			System.out.println("Press 0 : Exit");
			
			int choice = sc.nextInt();
			
	        switch (choice) {
	        case 1:
	        	employeeService.createEmployeeTable();
	    		System.out.println("\nDo you want to perform CRUD again? Type Yes / No");
	            if (sc.next().equalsIgnoreCase("no"))
	                    exit = true;
	                break;
	        case 2:
	        	employeeService.addNewEmployeeDetails();
	    		System.out.println("\nDo you want to perform CRUD again? Type Yes / No");
	            if (sc.next().equalsIgnoreCase("no"))
	                    exit = true;
	                break;
	        case 3:
	        	employeeService.showSinleEmployeeDetails();
	    		System.out.println("\nDo you want to perform CRUD again? Type Yes / No");
	            if (sc.next().equalsIgnoreCase("no"))
	                    exit = true;
	                break;
	        case 4:
	        	employeeService.showAllEmployeeDetails();
	    		System.out.println("\nDo you want to perform CRUD again? Type Yes / No");
	            if (sc.next().equalsIgnoreCase("no"))
	                    exit = true;
	                break;
	        case 5:
	        	employeeService.updateEmployeeDetails();
	    		System.out.println("\nDo you want to perform CRUD again? Type Yes / No");
	            if (sc.next().equalsIgnoreCase("no"))
	                    exit = true;
	                break;
	        case 6:
	        	employeeService.deleteEmployeeDetails();
	    		System.out.println("\nDo you want to perform CRUD again? Type Yes / No");
	            if (sc.next().equalsIgnoreCase("no"))
	                    exit = true;
	                break;
	        case 0:
	        	exit = true;
	        	System.out.println("Program Terminated");
	            break;
	        default:
	            break;
	        }
	    }   
    }
}
