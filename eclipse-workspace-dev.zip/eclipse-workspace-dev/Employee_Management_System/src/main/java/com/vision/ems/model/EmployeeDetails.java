package com.vision.ems.model;

public class EmployeeDetails {

	private int emp_id;
	private String name;
	private String designation;
	private String address;
	private String department;
	private double Salary;
	public int getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public double getSalary() {
		return Salary;
	}
	public void setSalary(double salary) {
		Salary = salary;
	}
	
	@Override
	public String toString() {
		return "Employee_Details [emp_id=" + emp_id + ", name=" + name + ", designation=" + designation + ", address="
				+ address + ", department=" + department + ", Salary=" + Salary + "]";
	}
	
}
