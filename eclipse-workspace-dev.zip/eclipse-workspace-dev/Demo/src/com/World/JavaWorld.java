package com.World;

public class JavaWorld {

	public static void main(String[] args) {
		System.out.println("First Java Program... Varsha Thinks...");

	}

}
