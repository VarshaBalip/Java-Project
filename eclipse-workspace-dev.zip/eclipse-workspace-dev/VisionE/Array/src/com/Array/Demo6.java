package com.Array;

public class Demo6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

int a2[]=new int[3];
a2[0]=1;
a2[1]=2;
a2[2]=3;
System.out.println(a2[0]);
System.out.println(a2[1]);
System.out.println(a2[2]);

	}

}
