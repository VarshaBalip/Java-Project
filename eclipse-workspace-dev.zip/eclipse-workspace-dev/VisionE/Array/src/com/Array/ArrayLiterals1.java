package com.Array;

public class ArrayLiterals1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a1 = { 10, 20, 30, 40, 50 };
		// for(int k:a1){
		System.out.println(a1[0]);
		System.out.println(a1[1]);
		System.out.println(a1[2]);
		System.out.println(a1[3]);
		System.out.println(a1[4]);
		System.out.println("size of an array:"+a1.length);
	}
}
