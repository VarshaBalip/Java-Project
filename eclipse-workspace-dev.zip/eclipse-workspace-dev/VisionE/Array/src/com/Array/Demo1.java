package com.Array;

public class Demo1 {


	public static void main(String[] args) {
		
	//int a1 [];declaration of array
	//int []a1;declaration of array
		
	int	a2[]=new int[10];//object creation of array
	System.out.println(a2[0]);	
	}

}
