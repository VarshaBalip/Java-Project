package com.Array;

public class Demo2 {
public static void main(String[]args){
	//here we didn't give any number hence we get default value 0.
	
	
	int a2[]=new int [10];
	a2[0]=1;
	System.out.println(a2[0]);
}
}
