package com.Array;

public class Demo4 {
public static void main(String[]args){
	
	double a2[]=new double[10];
	System.out.println(a2[5]);
}
}
