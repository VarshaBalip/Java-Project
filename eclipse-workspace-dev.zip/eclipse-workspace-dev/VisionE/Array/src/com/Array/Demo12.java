package com.Array;

public class Demo12 {
public static void main(String[]args){
	byte b=10;
	byte[]b1=new byte[b];
	b1[0]=1;
	b1[1]=2;
	b1[2]=3;
	b1[3]=4;
	System.out.println(b1.length);
	
}
}
