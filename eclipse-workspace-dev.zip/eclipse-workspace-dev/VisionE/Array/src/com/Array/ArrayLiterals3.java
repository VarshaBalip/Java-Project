package com.Array;

public class ArrayLiterals3 {

	public static void main(String[] args) {
float f1[]=new float[]{1,2,3};
System.out.println(f1[0]);
System.out.println(f1[1]);
System.out.println(f1[2]);
	}

}
