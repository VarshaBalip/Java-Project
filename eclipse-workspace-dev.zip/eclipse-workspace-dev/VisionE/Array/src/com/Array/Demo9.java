package com.Array;

public class Demo9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

int a2[]=new int[2147483647];
a2[0]=5;
a2[1]=10;
System.out.println(a2[2]);
	}

}
