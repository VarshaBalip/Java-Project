package com.Array;

public class ArrayLiterals2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
char c []=new char[]{'a','b','c'};
System.out.println("size of an array:"+c.length);
System.out.println(c[0]);
System.out.println(c[1]);
System.out.println(c[2]);
}

}
