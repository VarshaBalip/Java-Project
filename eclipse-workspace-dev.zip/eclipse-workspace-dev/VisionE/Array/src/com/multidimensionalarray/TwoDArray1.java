package com.multidimensionalarray;

public class TwoDArray1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int [][]a1=new int[2][];
a1[0]=new int[3];
a1[1]=new int[4];
a1[0][0]=1;
a1[0][1]=2;
a1[0][2]=3;
a1[1][0]=4;
a1[1][1]=5;
a1[1][2]=6;
a1[1][3]=7;
//int k1=a1[1][3];
//System.out.println(k1);
for(int i=0;i<a1.length;i++){
		for(int j=0;j<a1[i].length;j++){
			System.out.println(a1[i][j]);
		}
	}
}
		}


