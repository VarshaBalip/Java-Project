package com.multidimensionalarray;

public class TwoDArray2 {
	public static void main(String[]args){
		int a1[][]=new int [2][];
		a1[0]=new int[2];
		System.out.println("size of an a1[0] array:"+a1[0].length);
		a1[1]=new int[3];
		System.out.println("size of an a1[1] array:"+a1[1].length);
		a1[0][0]=10;
		a1[0][1]=20;
		a1[1][0]=30;
		a1[1][1]=40;
		a1[1][2]=50; 
		for(int i=0;i<a1.length;i++){
		for(int j=0;j<a1[i].length;j++)
		System.out.println(a1[i][j]);}
	}

}
