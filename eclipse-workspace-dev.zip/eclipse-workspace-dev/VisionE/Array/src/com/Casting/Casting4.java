package com.Casting;

public class Casting4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
