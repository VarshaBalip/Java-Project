package com.list_interface;

import java.util.ArrayList;
//list can store duplicate element
//list can store heterogeneous element
//list can have null(value) object also
//list can follow insertion order
//null duplicate also allowed are here
public class A {
public static void main(String[] args) {
	ArrayList a1=new ArrayList();
	a1.add(10);
	a1.add(10);
	a1.add("ABC");
	a1.add(null);
	a1.add(null);
	//a1.remove(null);
	//a1.clear();
	boolean contains=a1.contains(10);
	
	System.out.println(a1);
	System.out.println(contains);
	
}
}
