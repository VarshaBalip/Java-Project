package com.arraylist;

import java.util.ArrayList;

public class C {
public static void main(String[] args) {
	ArrayList a1=new ArrayList();
	a1.add(10);
	a1.add(20);
	System.out.println(a1);
	a1.addAll(a1);
	System.out.println(a1);
	boolean b1=a1.contains(5);
    System.out.println(b1);
    
    a1.ensureCapacity(0);
    System.out.println(a1);
    a1.iterator();//overall the element in list in proper sequence
    System.out.println(a1);
    
}
}
