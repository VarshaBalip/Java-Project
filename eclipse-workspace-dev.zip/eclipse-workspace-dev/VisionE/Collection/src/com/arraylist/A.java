package com.arraylist;

import java.util.ArrayList;
import java.util.LinkedList;
//arrayList is good choice if our frequent operation is of retrieve any object from list
//it implements random access interface:-to fetch any 

//arraylist class dont have capaciti of arraylist
//its default capacity 10
//we are 
public class A {
public static void main(String[] args) {
	//no arg constructor
	ArrayList al=new ArrayList();
	System.out.println(al.size());
	
	//initial capacity
	ArrayList al1=new ArrayList();
	System.out.println(al1.size());
	
	
	LinkedList l1=new LinkedList();
	//linked list collection object we have passed inside
	//constructor we can pass any collection object
	
	
}
}