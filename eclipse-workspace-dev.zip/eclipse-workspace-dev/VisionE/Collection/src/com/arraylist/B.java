package com.arraylist;

import java.util.ArrayList;

public class B {
public static void main(String[] args) {
	ArrayList a1=new ArrayList();
	a1.add(10);
	a1.add(20);
	a1.add(30);
	a1.add(50);
	
	System.out.println(a1);
	a1.remove(0);
	System.out.println(a1);
	Object k=a1.get(1);
	System.out.println(k);
	//System.out.println(a1.get(1));
	a1.add(3,40);
	a1.get(2);
	System.out.println(a1);
		
}
}
