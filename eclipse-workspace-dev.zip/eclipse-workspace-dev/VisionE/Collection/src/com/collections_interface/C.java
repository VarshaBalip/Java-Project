package com.collections_interface;

import java.util.Collections;
import java.util.List;

public class C {
public C m1() {
	return new C();
}
public static void main(String[] args) {
	C c1=new C();
	C c2=c1.m1();
	System.out.println(c2);
	
	//System.out.println(c2.hashCode());
}
}
