package com.collections_interface;
//we can apply collections method on any collection object
import java.util.ArrayList;
import java.util.Collections;

public class A {
public static void main(String[] args) {
	ArrayList a=new ArrayList();
	a.add(100);
	a.add(20);
	a.add(50);
	a.add(40);
	//a.add(10.0);
	//a.add(10.45f);
//	a.add("Hii");can not cast this string into integer
	System.out.println(a);
	Collections.sort(a);
	System.out.println(a);
}
}
