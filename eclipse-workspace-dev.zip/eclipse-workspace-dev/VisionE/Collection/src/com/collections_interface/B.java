package com.collections_interface;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

public class B {
public static void main(String[] args) {
	ArrayList a=new ArrayList();
	a.add(10);//this are Integer value not int value
	a.add(20);
	a.add(5000);
	a.add(400);
	a.add(1);
	System.out.println(a);
Integer i=Collections.min(a);
Integer i1=Collections.max(a);
	System.out.println(i);
	System.out.println(i1);
	//shuffle element
	Collections.shuffle(a);
	System.out.println(a);
	//[10, 5000, 400, 20, 1]
	//[10, 1, 20, 400, 5000]
	Collections.reverseOrder();
	System.out.println(a);
	Collections.reverse(a);
	

	//output of shuffle is it will shuffle the integer randomly

	//list emptylist
	List emptyList = Collections.emptyList();
    Set emptySet = Collections.emptySet();
    System.out.println(emptyList);
    System.out.println(emptySet);
	
}
}
