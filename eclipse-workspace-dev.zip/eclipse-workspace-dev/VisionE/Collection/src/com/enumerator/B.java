package com.enumerator;

public class B {
public B createObject() {
	return new B();
}
public static void main(String[] args) {
	B b1=new B();
	B b2=b1.createObject();
	System.out.println(b2 instanceof B);
}
}
