package com.sorted_set;

import java.util.TreeSet;

public class B {
public static void main(String[] args) {
	TreeSet t=new TreeSet();
	t.add("A");
	t.add("a");
	t.add("c");
	t.add("d");
	t.add("D");
	System.out.println(t);
}
}
