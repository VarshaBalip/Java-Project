package com.sorted_set;

import java.util.TreeSet;
//if we want to sort element based on natural sorting order using treeset
//JVM internally call for caompareto method which is present inside comparable method
public class CompareToMethod {
public static void main(String[] args) {
	TreeSet t=new TreeSet();
	t.add("T");
	t.add("A");
	t.add("P");
	t.add("E");
	System.out.println("T".compareTo("A"));
	System.out.println("A".compareTo("E"));
	System.out.println("A".compareTo("A"));
	

	System.out.println(t);
	
Object lower=	t.lower("A");
	System.out.println(lower);
	
	Object higher =t.higher("P");
	System.out.println(higher);
}
}
