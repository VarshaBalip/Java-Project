package com.sorted_set;

import java.util.SortedSet;
import java.util.TreeSet;
//heterogeneous element are not allowed for sortedset
//duplicate are not allowed
//elements are getting sorted into somesorting order
//default natural sorting order in case of sortedset is ascending in case of 
//integral object
//for alphanumerical objects default natural sorting order is A-Z
public class A {
public static void main(String[] args) {
	SortedSet s=new TreeSet();
	s.add(3);
	s.add(10);
	s.add(30);
	s.add(1);
	s.add(95);
	System.out.println(s);
	//after sorting this method will provide first element of set
	Object a1=s.first();
	System.out.println(a1);
	//it will provide last element
	Object a2=s.last();
	System.out.println(a2);
	//headset provide below that element that i hv putted
SortedSet  s1=s.headSet(10);
	System.out.println(s1);
	//tailset provide above that element that i hv putted
	SortedSet s2=s.tailSet(80);
	System.out.println(s2);
	//subset will provide between element that i hv putted
	SortedSet t1=s.subSet(10, 100);
	System.out.println(t1);
	
}
}
