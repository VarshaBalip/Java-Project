package com.collection_interface;

import java.util.ArrayList;

//collection is present in java.util package
//collection is group of heterogeneous element
//array is a group of homogeneous element
//drawback of array
//1)if i create array of int type data then we will store only int type data
//2)if we create a size of array then it will be fix for that program,we cant add any other data
//these two drawbacks overcome by collection
public class A {
public static void main(String[] args) {
	//list is interface present inside java.util package
	//1)ArrayList 2)LinkedList 3)Vector 4)Stack
	ArrayList a=new ArrayList();
	a.add("Hii");
	a.add("Varsha");
	a.add(10);//this 10 is Integer Value not int value i.e.wrapper class
	a.add('p');//this p is Character type data not char type i.e.wrapper class
	a.add(10.0);//this 10.0 is 
	System.out.println(a);
	//a.remove(1);
//	System.out.println(a);
	System.out.println(a.get(1));
	//a.clear();
	//System.out.println(a);
	boolean contains=a.contains("Varsha");
	System.out.println(contains);
	boolean contains1=a.contains("Hii");
	System.out.println(contains1);
	
	
	
}
}
