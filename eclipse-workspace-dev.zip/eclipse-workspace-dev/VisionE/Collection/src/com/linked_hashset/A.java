package com.linked_hashset;

import java.util.LinkedHashSet;

public class A {
//list insertion order to be preserved
	// set duplicates are allowed
	public static void main(String[] args) {
		LinkedHashSet l=new LinkedHashSet();
		l.add(10);
		l.add(20);
		l.add(20);
		System.out.println(l);
		  
		//initial capacity
		LinkedHashSet l1=new LinkedHashSet(100);
		System.out.println(l1);
		
		//constructor initial capacity and load factor
		LinkedHashSet l2=new LinkedHashSet(1000,0.70f);
		System.out.println(l2);
		l.add(50);
		l.add(100);
		l.add(50);
		LinkedHashSet s=new LinkedHashSet(l);
		System.out.println(s);
	
	}
}
