package com.collection_interface_method;
//toArray  method
//we are converting here collection to array
import java.util.ArrayList;
import java.util.Collection;

public class H {
public static void main(String[] args) {
	Collection c=new ArrayList();
	c.add(10);
	c.add(100);
	c.add("Varsha");
	c.add('A');
//	int[]array=c.toArray();
	Object[]array=c.toArray();//if we want to any type of data then we will go for Object
	//object is a parent of all classes
	//System.out.println(c.toArray());
	
	for(Object a:array) {
		System.out.println(a);
	}
	
}
}
