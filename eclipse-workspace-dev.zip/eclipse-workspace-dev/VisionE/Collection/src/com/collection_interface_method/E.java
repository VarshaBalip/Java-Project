package com.collection_interface_method;
//removeAll method
import java.util.ArrayList;
import java.util.Collection;

public class E {
public static void main(String[] args) {
	Collection c=new ArrayList();
	
	c.add(100);
	c.add(200);
	c.add(300);
	//c.add(400);
	
	Collection c1=new ArrayList();
	c1.add(100);
	c1.add(200);
	c1.add(300);
	System.out.println(c);
	System.out.println(c1);
	//after removeAll
	
	c.removeAll(c1);
	System.out.println(c);
	System.out.println(c1);
}
}
