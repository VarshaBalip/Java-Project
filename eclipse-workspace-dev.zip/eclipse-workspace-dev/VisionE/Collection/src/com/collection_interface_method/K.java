package com.collection_interface_method;
//retainAll method
import java.util.ArrayList;
import java.util.Collection;

public class K {
public static void main(String[] args) {
	Collection c=new ArrayList();
	c.add(10);
	c.add(20);
	c.add("Varsha");
	//System.out.println(c);
	
	ArrayList a=new ArrayList();
	a.add(100);
	a.add(200);
	a.add(300);
	a.add(400);
	//System.out.println(a);
	
	ArrayList a1=new ArrayList();
	a1.add(100);
	a1.add(200);
	a1.add(600);
	//System.out.println(a1);
	a.retainAll(a1);
	System.out.println(a);
	System.out.println(a1);
}
}
