package com.collection_interface_method;
//remove method
import java.util.ArrayList;
import java.util.Collection;

public class D {
public static void main(String[] args) {
	Collection c=new ArrayList();
	c.add(100);
	c.add(200);
	c.add(300);
	System.out.println(c);
	c.remove(100);
	System.out.println(c);
	
}
}
