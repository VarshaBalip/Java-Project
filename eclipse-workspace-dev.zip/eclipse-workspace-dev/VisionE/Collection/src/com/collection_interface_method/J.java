package com.collection_interface_method;

import java.util.ArrayList;
import java.util.Collection;

public class J {
public static void main(String[] args) {
	Collection c=new ArrayList();
	c.add(10);
	c.add(20);
	c.add("Varsha");
	//System.out.println(c);
	
	//new object
	ArrayList a=new ArrayList();
	a.add(30);
	a.add(40);
	a.add("Balip");
	//System.out.println(a);
	
	//new object
	ArrayList a1=new ArrayList();
	a1.add(30);
	a1.add(40);
	a1.add("Ashvik");
	//System.out.println(a1);
	
	//boolean b=a.containsAll(a1);
	System.out.println(a.contains(a1));
	//System.out.println(a);
	//System.out.println(a1);
	
	
}
}
