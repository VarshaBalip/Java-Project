package com.collection_interface_method;
//clear method
import java.util.ArrayList;
import java.util.Collection;

public class F {
public static void main(String[] args) {
	Collection c=new ArrayList();
	c.add(10);
	c.add(20);
	System.out.println(c);
	c.clear();
	System.out.println(c);
	
	
}
}
