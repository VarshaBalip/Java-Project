package com.collection_interface_method;

public interface B {

}
