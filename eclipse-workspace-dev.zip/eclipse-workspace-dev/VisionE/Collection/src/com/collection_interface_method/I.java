package com.collection_interface_method;
//addAll method
import java.util.ArrayList;
import java.util.Collection;

public class I {
public static void main(String[] args) {
	Collection c=new ArrayList();//arrayList is a object
	c.add(10);//10 it is also object in Integer type
	c.add(20);
	c.add(30);
	c.add("Varsha");
	c.add('D');
	//creating new object
	//I i=new I();//i also object
	//c.add(i);
	ArrayList a=new ArrayList();
	a.add(100);
	a.add(200);
	//c.add(a);
//	System.out.println(c);
	c.addAll(a);
	System.out.println(c);
}
}
