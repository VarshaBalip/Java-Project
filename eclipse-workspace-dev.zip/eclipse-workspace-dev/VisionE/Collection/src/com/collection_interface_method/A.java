package com.collection_interface_method;

public class A implements B{
public static void main(String[] args) {
	A a1=new A();
	B b1=new A();
	
}
}
