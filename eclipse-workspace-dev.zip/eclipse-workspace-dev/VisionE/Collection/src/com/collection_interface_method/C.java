package com.collection_interface_method;
//size method
import java.util.ArrayList;
import java.util.Collection;

public class C {
public static void main(String[] args) {
	Collection c=new ArrayList();
	int i=c.size();
	c.add("Varsha");
	c.add(10);
	System.out.println(c);
	System.out.println(c.size());
}
	
}
