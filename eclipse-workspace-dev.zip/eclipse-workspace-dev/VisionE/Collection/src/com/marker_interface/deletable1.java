package com.marker_interface;

public class deletable1 {

}
