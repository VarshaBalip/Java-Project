package com.marker_interface;
//Cloneable is a marker interface which does not have any abstract methods
public class A implements Cloneable {
public static void main(String[] args)throws CloneNotSupportedException {
A a1=new A();
a1.clone();

}
}
