package com.marker_interface;

public class AA1 implements deletable{
public String deleteobject(Object object){
	
	if(object instanceof deletable) {
		return "we can delete object";
	}
	else {
		return "we can not delete object";
	}
}
public static void main(String[] args) {
	AA1 a1=new AA1();
	System.out.println(a1 instanceof deletable);
	AA1 a2=new AA1();
	BB1 b1=new BB1();
	System.out.println(a1.deleteobject(b1));
	System.out.println(a1.deleteobject(a2));
}
}
