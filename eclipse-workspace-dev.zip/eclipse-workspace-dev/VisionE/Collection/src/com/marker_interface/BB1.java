package com.marker_interface;

public class BB1 {

}
