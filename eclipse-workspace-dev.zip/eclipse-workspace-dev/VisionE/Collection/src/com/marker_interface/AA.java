package com.marker_interface;

public class AA implements deletable {
	public String deleteobject(Object object ) {
if(object instanceof deletable) {
	return "we can delete object";
}
else {
	return "we can not delete object";
}
	
}
	public static void main(String[] args) {
		AA a1=new AA();
		System.out.println(a1 instanceof deletable);
		AA a2=new AA();
		BB b1=new BB();
		System.out.println(a1.deleteobject(a2));
		System.out.println(a1.deleteobject(b1));
		
		
	}
}
