package com.marker_interface;

public class A1  implements Cloneable{
	public static void main(String[] args) throws CloneNotSupportedException {
		A1 a1=new A1();
		a1.clone();
		
		
	}
}