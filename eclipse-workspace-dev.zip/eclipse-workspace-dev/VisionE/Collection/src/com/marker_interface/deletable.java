package com.marker_interface;

public interface deletable {

}
