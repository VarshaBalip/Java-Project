package com.iterator_cursor;

import java.util.ArrayList;
import java.util.Iterator;

public class A {
public static void main(String[] args) {
	ArrayList a=new ArrayList();
	a.add(10);
	a.add(20);
	a.add(30);
	a.add(40);
	a.add(50);
	a.add(60);
	a.add(70);
	a.add(80);
	a.add(90);
	a.add(100);
	Iterator e=a.iterator();
	while(e.hasNext()) {
		Integer next=(Integer)e.next();
		System.out.println(next);
		if(next==70) {//it will remove 70
			e.remove();
		}
	}
	System.out.println(a);
}
}
