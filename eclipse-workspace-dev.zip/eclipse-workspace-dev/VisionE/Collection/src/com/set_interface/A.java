package com.set_interface;

import java.util.HashSet;
import java.util.Set;

public class A {
public static void main(String[] args) {
	Set s=new HashSet();
	boolean a=s.add(10);//true
	boolean b=s.add(10);//false
	boolean c=s.add(30);
	boolean d=s.add(50);
	System.out.println(a+"  "+b+"    "+c+"   "+d);
System.out.println(s);
	
}
}
