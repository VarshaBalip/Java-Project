package com.set_interface;

import java.util.LinkedHashSet;

public class D {
public static void main(String[] args) {
	LinkedHashSet h=new LinkedHashSet();
	h.add(10);
	h.add(20);
	h.add(30);
	h.add(40);
	h.add(50);
	System.out.println(h);
	
	LinkedHashSet h1=new LinkedHashSet();
	h1.addAll(h);
	System.out.println(h1);
	h1.clear();
	System.out.println(h1);
	
	
}
}
