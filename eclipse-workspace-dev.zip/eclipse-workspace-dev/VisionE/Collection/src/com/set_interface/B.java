package com.set_interface;

import java.util.HashSet;

public class B {
public static void main(String[] args) {
	HashSet h=new HashSet();
	h.add(10);
	h.add("A");
	h.add("10.0f");
	System.out.println(h);
	h.add("abc");
	h.add(15);
	System.out.println(h);

	
	HashSet h1=new HashSet();
	h1.add("Varsha");
	h1.addAll(h);
	System.out.println(h1);
//	h1.clear();
//	System.out.println(h1);

	h1.clone();
	System.out.println(h1);
	System.out.println(h1.contains("Varsha"));
	System.out.println(h1.retainAll(h));
	System.out.println(h1.containsAll(h));
	boolean b=h1.isEmpty();
	System.out.println(b);
}
}
