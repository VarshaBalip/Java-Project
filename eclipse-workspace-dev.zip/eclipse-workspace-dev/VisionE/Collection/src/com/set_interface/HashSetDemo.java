package com.set_interface;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class HashSetDemo {
public static void main(String[] args) {
	HashSet h=new HashSet ();
	//no arg constructor
	//default capacity=16;
	//default fill ratio or load factor =0.75
	//16=100%;
	//12=75%;
	ArrayList l=new ArrayList();
	l.add(10);
	l.add(10);
	l.add(20);
	System.out.println(l);
	//collection arg constructor
	HashSet h1=new HashSet(l);//load factor 75%
	System.out.println(h1);
	
	//initial capacity constructor
	HashSet h2=new HashSet(100);//load factor 75%
	l.add(1000);
	l.add(2000);
	l.add(2000);
	System.out.println(h2);
	
	//initial capacity and load factor constructor
	HashSet h3=new HashSet(100,0.75f);//customize load factor
	System.out.println(h3);
}
}
