package com.set_interface;

import java.util.HashSet;

public class LoadFactor {
public static void main(String[] args) {
	HashSet h=new HashSet();//default capacity 16
	//fill ratio
	//16=100%
	//12=75%
	//8=50%
}
}
