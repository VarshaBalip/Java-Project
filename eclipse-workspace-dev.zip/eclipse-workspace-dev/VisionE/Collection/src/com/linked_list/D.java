package com.linked_list;

import java.util.LinkedList;
import java.util.ListIterator;

public class D {
public static void main(String[] args) {
	LinkedList a=new LinkedList();
	a.add(100);
	a.add(200);
	a.add(300);
	a.add(400);
	a.add(500);
	a.add(600);
	a.add(700);
	a.add(800);
	a.add(900);
	a.add(1000);
	System.out.println(a);
	
	ListIterator e=a.listIterator();
int i=e.nextIndex();
System.out.println(i);
System.out.println(e.next());


System.out.println(e.nextIndex());
System.out.println(e.hasNext());//true
System.out.println(e.previous());
System.out.println(e.nextIndex());
System.out.println(e.previousIndex());
System.out.println(a);
a.remove(1);
System.out.println(a);
}
}
