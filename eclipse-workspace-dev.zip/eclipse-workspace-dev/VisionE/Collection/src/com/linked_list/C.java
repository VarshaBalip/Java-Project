package com.linked_list;

import java.util.Iterator;
import java.util.LinkedList;

public class C {
public static void main(String[] args) {
	LinkedList l=new LinkedList();
	l.add(10);
	l.add(20);
	l.add(30);
	l.add(40);
	l.add(50);
	l.add(60);
	l.add(70);
	l.add(80);
	l.add(90);
	l.add(100);
	System.out.println(l);
	
	Iterator e=l.iterator();
	while(e.hasNext()) {
		Integer next=(Integer)e.next();
		System.out.println(next);
	
	if(next==50) {
		e.remove();
	}
	}
	System.out.println(l);
	}

}
