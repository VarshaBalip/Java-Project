package com.linked_list;

import java.util.ArrayList;
import java.util.LinkedList;

public class B {
public static void main(String[] args) {
	//ArrayList l1=new ArrayList();
	LinkedList l1=new LinkedList();
	l1.add(10);
	l1.add(1,20);
	System.out.println("output of add method:"+l1);
	l1.addAll(l1);//addAll method
	System.out.println("output of addAll method:"+l1);

	LinkedList l2=new LinkedList();
	l2.addAll(0,l1);
	l2.addFirst(10);
	l2.addLast(100);
	System.out.println("output of addFirst and addLast method:"+l2);
	l2.clear();
	System.out.println("output of clear method:"+l2);
	
	LinkedList l3=new LinkedList();
	l3.clone();
	System.out.println("clone method:"+l3);
	l3.add(100);
	l3.add(200);
	l3.add(300);
	boolean b1=l3.contains(100);
	System.out.println("contains method output:"+b1);
	l3.containsAll(l3);
	System.out.println("output of containsAll method:"+l3);
	
	LinkedList l4=new LinkedList();
	l4.add(1);
	l4.add(2);
	l4.add(3);
	l4.add(4);
	l4.add(5);
	l4.descendingIterator();
	System.out.println(" output of descending iterator method:"+l4);
	l4.element();
	System.out.println("output of elemement method:"+l4);
	 Object k=l4.equals(l1);
	 System.out.println("output of equals method:"+k);
	 l4.get(0);
	 System.out.println("output of index method:"+l4);
	Object k1= l4.getFirst();
	System.out.println("output of getFirst method:"+k1);
	Object k2=l4.getLast();
	System.out.println("output of getLast method:"+k2);
	
	
	LinkedList l5=new LinkedList();
	l5.add(15);
	Object m=l5.hashCode();
	System.out.println("output of hashcode method:"+m);
	Object m1=l5.indexOf(15);
	System.out.println("output of indexof method:"+m1);
	
	boolean s1=l5.isEmpty();
	System.out.println("output of boolean method:"+s1);
	
	
	
	
	
	
}
}
