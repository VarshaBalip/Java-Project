package com.linked_list;

import java.util.ArrayList;
import java.util.LinkedList;

public class A {
public static void main(String[] args) {
	//constructor that accepts collection object
	ArrayList a1=new ArrayList();
	//linked list is better choice to add/delete element in between
	//linked list underlying datastructure is doublinked list
	LinkedList l2=new LinkedList(a1);
	//no arg constructor
	LinkedList l1=new LinkedList();
	l1.add(10);
	l1.add(20);
	l1.add("Varsha");
	l1.add("Varsha");//you can add duplicate also
	l1.add(30);
	l1.add(null);
	l1.add(null);
	System.out.println(l1);
	l1.add(1,"xyz");
	l1.remove();
	l1.add(0,"Ashvik");
	System.out.println(l1);
	Object k=l1.set(1,"abc");
    System.out.println(l1);
    
}
}
