package com.stack;

import java.util.Stack;

public class A {
public static void main(String[] args) {
	Stack c=new Stack();
	c.push(10);
	c.push(20);
	c.push(30);
	c.push(40);
	System.out.println(c);
	//c.pop();//lasi in first out
	//System.out.println(c);
	boolean b=c.empty();
	System.out.println(b);
	System.out.println(c.search(10));
	System.out.println(c.search(50));
}
}
