package com.vector;

import java.util.Vector;

public class A {
public static void main(String[] args) {
	Vector v=new Vector();
	v.addElement(10);
	v.addElement(20);
	v.add(30);
	System.out.println(v);
	v.remove(2);
	System.out.println(v);
}
}
