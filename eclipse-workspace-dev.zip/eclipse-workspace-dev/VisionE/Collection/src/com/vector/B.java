package com.vector;

import java.util.Vector;

public class B {
public static void main(String[] args) {
	//no arg construvtor
	Vector v=new Vector();
	System.out.println(v.capacity());
    v.add(10);
    v.add(20);
    v.add(30);
    v.add(40);
    v.add(50);
    v.add(60);
    v.add(70);
    v.add(80);
    v.add(90);
    v.add(100);
    System.out.println(v.capacity());
    //11th no.object
    v.add("A");
    System.out.println(v.capacity());
    
    //constructor with initial capacity
    Vector v1=new Vector();
    v1.add(10);
    v1.add(10);
    v1.add(10);
    v1.add(10);
    System.out.println(v1.capacity());
    v1.trimToSize();
    System.out.println(v1.capacity());
    
    //int initial capacity ,int incremental capacity
    Vector v2=new Vector(3,10);
    v2.add(10);
    v2.add(20);
    v2.add(30);
    v2.add(40);
    System.out.println(v2.capacity());
    System.out.println(v2);
}
}
