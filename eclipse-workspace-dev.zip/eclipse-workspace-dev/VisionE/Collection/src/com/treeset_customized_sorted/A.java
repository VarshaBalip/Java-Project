package com.treeset_customized_sorted;

import java.util.TreeSet;

public class A {
public static void main(String[] args) {
	TreeSet t=new TreeSet(new A1());
	//compare(obj1,obj2)
	t.add(10);
	t.add(40);
	t.add(30);
	t.add(60);
	t.add(5);
	System.out.println("customized sorting order:"+t);
	
}
}
