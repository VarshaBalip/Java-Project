package com.treeset_customized_sorted;

import java.util.Comparator;
import java.util.TreeSet;

public class A1 implements Comparator{

public int compare(Object o1, Object o2) {
Integer a1=(Integer)o1;
Integer a2=(Integer)o2;
if(a1>a2) {
	return -1;
}
	if(a1<a2) {
		return +1;
	}
	else {
		return 0;
	}

}
}