package com.list_iterator;

import java.util.ArrayList;
import java.util.ListIterator;

public class A {
public static void main(String[] args) {
	ArrayList l1=new ArrayList();
	l1.add(10);
	l1.add(20);
	l1.add(30);
	l1.add(40);
	l1.add(50);
	l1.add(60);
	l1.add(70);
	l1.add(80);
	l1.add(90);
	l1.add(100);
	  
	ListIterator l=l1.listIterator();
	while(l.hasNext()) {
		System.out.println(l.next());
	}
	while(l.hasPrevious()) {
		System.out.println(l.previous());
	}
	
	
}
}
