package com.list_iterator;
import java.util.ArrayList;
import java.util.ListIterator;

public class B {
	
	public static void main(String[] args) {
		ArrayList l1=new ArrayList();
		l1.add(10);
		l1.add(20);
		l1.add(30);
		l1.add(40);
		l1.add(50);
		l1.add(60);
		l1.add(70);
		l1.add(80);
		l1.add(90);
		l1.add(100);
		
		ListIterator l=l1.listIterator();
		int i=l.nextIndex();
		System.out.println(i);
		System.out.println(l.next());
		//System.out.println(l.next());
		//it will print object
		System.out.println(l.nextIndex());
		System.out.println(l.previousIndex());
		System.out.println(l1);
		l.remove();
		System.out.println(l1);
		l.add(110);
		System.out.println(l1);
		l.next();
		l.set(120);
		System.out.println(l1);
		
		
		
		  
}}
