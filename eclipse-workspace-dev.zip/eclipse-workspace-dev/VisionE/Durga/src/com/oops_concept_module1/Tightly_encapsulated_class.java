package com.oops_concept_module1;

public class Tightly_encapsulated_class {
//private double balance;
//public double getbalance();
//return balance
}
//1)question:which of the following class is tightly encapsulated?
//answer:class A is tightly encapsulated
class A{
	private int x=10;
}
class B extends A{
	int y=20;
}
class c extends A{
	private int z=30;
}
//2)question:which of the following class is tightly encapsulated?
//answer:no class is tightly encapsulalted
//because :if parent class is not tightly encapsulated then no child class 
//will be tightly encapsulated
class x{
	int x=0;	
}
class y extends x{
	private int y=10;
}
class z extends y{
	private int z=15;
}