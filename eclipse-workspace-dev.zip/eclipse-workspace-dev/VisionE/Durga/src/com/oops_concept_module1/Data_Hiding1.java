package com.oops_concept_module1;
//by using private keyword we can hide our data from outsider person
//main advantages of data hiding is security purpose
public class Data_Hiding1 {
private double balance;


//public double getbalance();
//validation
//return balance;
}
