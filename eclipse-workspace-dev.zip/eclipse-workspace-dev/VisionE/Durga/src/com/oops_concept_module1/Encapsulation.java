package com.oops_concept_module1;
//encapsulation:wrapping or binding data members and behaviour into a single unit
//combination of data hiding and abstraction such type of component is said to be encapsulated
	//component.
	//encapsulation=data hiding+abstraction
public class Encapsulation {
//data members 
//+
//methods(behavior)
	//private double balance;
//	public double getbalance();
	//return balance
	//public void setbalance(double balance) {
	//	this.balance=balance;
	}
//}
