package com.oops_concept_module1;
//abstraction: shows essential services to users without displaying internal implementation
//by using interfaces and abstract classes we can implement abstraction
public class Abstraction1 {
//advantages of abstraction
	//1)outside person does not aware of our internal implementation;we can achieve security
	//2)without affecting outside person we can able to perform any type of changes
	//in our internal system ,hence enhancement will be become easy
	//3)abstraction improve easiness to our system
	//4)it improves maintainability to our system
	//
}
