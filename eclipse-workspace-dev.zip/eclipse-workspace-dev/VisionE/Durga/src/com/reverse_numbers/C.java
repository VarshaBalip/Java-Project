package com.reverse_numbers;

import java.util.Scanner;

public class C {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number:");
		int num=sc.nextInt();//1234
		
		//using stringBuilder class
		StringBuilder sb=new StringBuilder();
		sb.append(num);
	StringBuilder	rev=sb.reverse();
		System.out.println("reverse number is:"+rev);
		
}}
