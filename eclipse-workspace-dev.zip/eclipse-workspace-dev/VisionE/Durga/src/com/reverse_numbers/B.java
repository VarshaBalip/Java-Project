package com.reverse_numbers;

import java.util.Scanner;

public class B {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number:");
		int num=sc.nextInt();//1234
		
		
		//2.using stringbuffer class method
		StringBuffer rev;
		StringBuffer sb=new StringBuffer(String.valueOf(num));
	    StringBuffer rev1=sb.reverse();
		System.out.println("reverse number is:"+rev1);
}
}