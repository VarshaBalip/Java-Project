package com.selectionstatement;

public class Switch7Valid {
public static void main(String[]args){
	int x=10;
	switch(x+1)
	{
	case 10:
		System.out.println(10);
		
	case 10+1:
		System.out.println(11);
	}
}
}
