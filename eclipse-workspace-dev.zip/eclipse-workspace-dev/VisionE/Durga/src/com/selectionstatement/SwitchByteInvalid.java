package com.selectionstatement;

public class SwitchByteInvalid {
public static void main(String[]args){
	byte b=10;
	switch(b){
	case 10:
		System.out.println(10);
		//if we write here case 500 and case 1000 it is invalid bcoz byte data range is -128 to 127
	//case 500:
		//System.out.println(50);
	//case 1000:
		//System.out.println(100);
	}
}
}
