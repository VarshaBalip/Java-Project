package com.selectionstatement;

public class IfElse6 {
	public static void main(String[]args){
		
		if(true)
			System.out.println("hello");
		
	}
}
