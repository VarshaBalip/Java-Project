package com.selectionstatement;

public class Switch6 {
public static void main(String[]args){
	int x=10;
	int y=20;
	switch(x){
	case 10:
	System.out.println("i am pooja");
	}
	switch(y){
	case 20:
		System.out.println("i am diyara");
	}
}
}
