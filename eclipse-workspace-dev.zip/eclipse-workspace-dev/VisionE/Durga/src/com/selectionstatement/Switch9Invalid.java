package com.selectionstatement;

public class Switch9Invalid {
public static void main(String[]args){
	int x=10;
	switch(x){
	case 97:
		System.out.println(97);
	case 98:
		System.out.println(98);
	case 99:
		System.out.println(99);
		//if we write here case a it is invalid
	//case a:
		//System.out.println(a);
	}
}
}
