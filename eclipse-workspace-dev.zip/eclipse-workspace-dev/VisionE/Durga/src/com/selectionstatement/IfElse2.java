package com.selectionstatement;

public class IfElse2 {
	public static void main(String[] args) {
		int x = 10;
		if (x == 20) {
			System.out.println("hello");

		} else {
			System.out.println("hii");
		}
	}
}
