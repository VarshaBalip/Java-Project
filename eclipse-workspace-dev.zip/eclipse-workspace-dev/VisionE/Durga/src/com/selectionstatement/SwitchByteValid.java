package com.selectionstatement;

public class SwitchByteValid {
public static void main(String[]args){
	byte b=10;
	switch(b+1){
	case 10:
		System.out.println(10);
		//if we write here case 500 and case 1000 then it is valid in this case
		//becoz b+1 it has int type data
	case 500:
		System.out.println(500);
	case 1000:
		System.out.println(1000);
	
	}
}
}
