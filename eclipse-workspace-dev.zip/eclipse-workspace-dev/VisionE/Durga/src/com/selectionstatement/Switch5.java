package com.selectionstatement;

public class Switch5 {
	public static void main(String[]args){
char x=0;
switch(x){
case 0:
	System.out.println("i am pooja");
}
}}
