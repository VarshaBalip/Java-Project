package com.declarations;
import java.util.ArrayList;
public class D {
public static void main(String[] args) {
	//java.util.Arraylist l=new java.util.ArrayList();//fully qualified name
	//import java.util.ArrayList 
	// import statement act as typing shortcut,hence there is no requrement to write every
	//time fully qualiied name
	ArrayList l=new ArrayList();//shortcut
}
}
