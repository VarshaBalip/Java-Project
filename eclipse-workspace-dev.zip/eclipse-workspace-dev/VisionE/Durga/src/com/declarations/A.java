package com.declarations;

 class A {

}
class B{
	
}
class C{
	
}//if there is no public hence we can give any name to our program
//if there is public in B class then we have to give name to our program is B.java
//if there is two public classes B and C it is invalid declaration