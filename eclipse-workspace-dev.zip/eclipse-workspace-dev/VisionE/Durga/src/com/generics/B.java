package com.generics;

import java.util.ArrayList;

//generic is used for type safety
///for type casting
public class B {
	public static void main(String[] args) {
	
	
//in the case of array at the time of retrival it is not requirement to perform
	//typecasting because there is a guarantee for the type of elements
	//present inside array
	String[]s=new String[10000];
	s[0]="pooja";
	String name=s[0];//type casting not requre
	
	
	//but in the case of collection at the time retrival compulsary we should 
	//perform typecasting because there is no guarantee for the type of elements 
	//present inside array
	
	ArrayList l=new ArrayList();
	l.add("pooja");
	//String name=l.get(0);//it will get compile time error
	String name1=(String)l.get(0);//type casting is mandotory
	
	//to overcome above problem of collections some people introduced the
	//generic concept hence the main objective of generics are
	//1) to provide type safety
	//2)to resolve typecasting problems
}
}
