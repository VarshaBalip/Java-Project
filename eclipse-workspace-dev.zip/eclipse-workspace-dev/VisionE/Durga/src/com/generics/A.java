package com.generics;

import java.util.ArrayList;

public class A {
	public static void main(String[] args) {
		
	
//array is a type safety
	//if our program reqirement is hold only string type of object we choose string type array
	//by mistakw if we are trying add anther type of object we will get compile time error
	String []s=new String[1000];
	s[0]="pooja";
	s[1]="anarthe";
//	s[2]=new Integer(10);//compile time error
	

//but collections are not type safe i.e.we cant give guarantee ffor the type of elements 
//present inside collections
//foreg.if our program requremnt hold only string type of object and if we choose arraylist
//by mistake we are trying to add any other type object we won't get compile time error
//but program will get fail at runtime

ArrayList l=new ArrayList();
l.add("pooja");
l.add("ravi");

	}
}