package com.fallthroughinsideswitch;

public class Switch1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int x=0;
switch(x){
case 0:
	System.out.println(0);
case 1:
	System.out.println(1);
case 2:
	System.out.println(2);
	default:
		System.out.println("def");
}
	}

}
