package com.throw_exception;

public class B {
public static void main(String[] args) {
	throw new NullPointerException("");
	
}
}
