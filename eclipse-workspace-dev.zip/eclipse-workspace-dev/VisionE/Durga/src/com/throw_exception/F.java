package com.throw_exception;

public class F {
public static void main(String[] args) {
	throw new IllegalArgumentException();
}
}
