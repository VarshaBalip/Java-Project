package com.throw_exception;

public class A {
public static void main(String[] args) {
//	System.out.println(10/0);
//
	throw new ArithmeticException("10/0");
	}
}
