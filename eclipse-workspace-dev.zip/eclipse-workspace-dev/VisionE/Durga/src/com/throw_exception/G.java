package com.throw_exception;

public class G {
public static void main(String[] args) {
	throw new IllegalStateException();
}
}
