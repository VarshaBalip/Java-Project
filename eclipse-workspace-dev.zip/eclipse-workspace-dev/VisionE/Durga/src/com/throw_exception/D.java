package com.throw_exception;

public class D {
public static void main(String[] args) {
	throw new NegativeArraySizeException();
}
}
