package com.throw_exception;

public class E {
public static void main(String[] args) {
	throw new IndexOutOfBoundsException();
}
}
