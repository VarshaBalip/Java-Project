package com.transferstatement;
// inside switch to stop fall throgh we are using break statement
public class Break_InsideSwitch1 {
public static void main(String[]args){
	int x=0;
	switch(x){
	case 0:
	System.out.println("january");
	break;
	case 1:
		System.out.println("february");
	}
}
}
