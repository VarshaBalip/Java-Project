package com.java.lang_package;

import java.util.ArrayList;

public class B {
public static void main(String[] args) {
	String s=new String("pooja");
	System.out.println(s);
	Integer I=new Integer(10);
	System.out.println(I);
	
	
	ArrayList a=new ArrayList();
	a.add("A");
	a.add("B");
	System.out.println(a);
	
	
}
}
