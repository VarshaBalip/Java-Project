package com.java.lang_package;

public class E {
public static void main(String[] args) {
	StringBuffer sb=new StringBuffer();
	sb.append("pi value is:");
	sb.append(3.14);
	sb.append("it is exactly:");
	sb.append(true);
	System.out.println(sb);
	
}
}
