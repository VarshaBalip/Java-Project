package com.java.lang_package;

public class Student {
String name;
int rollno;
Student(String name,int rollno){
	this.name=name;
	this.rollno=rollno;
	
}
public static void main(String[] args) {
	Student s1=new Student("pooja",1);
	Student s2=new Student ("diyara",2);
	Student s3=new Student("satish",3);
//	System.out.println(s1.equals(s2));false
//	System.out.println(s1.equals(s3));false
//	System.out.println(s1.equals("pooja"));false
//	System.out.println(s1.equals(null));false
	System.out.println(s1);
	System.out.println(s2.toString());
	System.out.println(s2);
}
@Override
public String toString() {
	return "Student [name=" + name + ", rollno=" + rollno + "]";
}
}
