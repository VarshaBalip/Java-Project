package com.java.lang_package;

public class D {
public static void main(String[] args) {
	StringBuffer sb=new StringBuffer();
	sb.append("abcdefghijklmnopqrstuvwxyz");//capacity 34
	//sb.append("a");//capacity 16
	//sb.append("A");//capacity 16
	System.out.println(sb.charAt(0));
	
	System.out.println(sb.capacity());
}
}
