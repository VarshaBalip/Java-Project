package com.java.lang_package;

import java.lang.reflect.Method;

public class C {
public static void main(String[] args) {
	int count=0;
	Object o=new String("pooja");
	Class c=o.getClass();
	System.out.println(c.getClass());
	Method[]m=c.getDeclaredMethods();
	System.out.println("methods information");
	for(Method m1:m) {
		count++;
		System.out.println("fully qualified name:"+m1.getName());
	}
	System.out.println("the number of methods:"+count);
}
}
