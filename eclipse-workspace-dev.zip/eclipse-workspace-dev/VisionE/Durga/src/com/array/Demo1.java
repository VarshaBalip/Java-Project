package com.array;

public class Demo1 {
	public static void main(String[] args) {
		int[][] x1 = new int[3][];
		x1[0] = new int[3];
		x1[1] = new int[2];
		x1[0][0] = 1;
		x1[0][1] = 2;
		x1[0][2] = 3;
		x1[1][0] = 4;
		x1[1][1] = 5;

		for (int i = 0; i < x1.length; i++) {
			for (int j = 0; j < x1[i].length; j++) {
				System.out.println(x1[i][j]);
			}
		}
	}
}
