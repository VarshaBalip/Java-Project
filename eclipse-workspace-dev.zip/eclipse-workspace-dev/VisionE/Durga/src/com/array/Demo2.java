package com.array;

public class Demo2 {
public static void main(String[]args){
	int[][]x= new int[5][];
	x[0]= new int[2];
	x[1]=new int[3];
	x[2]=new int[4];
	x[0][0]=1;
	x[0][1]=2;
	x[1][0]=3;
	x[1][1]=4;
	x[1][2]=5;
	x[2][0]=6;
	x[2][1]=7;
	x[2][2]=8;
	x[2][3]=9;
	
	for(int i=0;i<x.length;i++){
		for	(int j=0;j<x[i].length;j++){
			
				System.out.println(x[i][j]);
				
		}
		}
	}
}

