package com.array;

public class Demo3 {
public static void main(String[] args) {
	int x[][]=new int[5][];
	 x[0]=new int[4];
	 x[1]=new int[2];
	 x[2]=new int[2];
	 x[0][0]=1;
	 x[0][1]=2;
	 x[0][2]=3;
	 x[0][3]=4;
	 x[1][0]=5;
	 x[1][1]=6;
	 x[2][0]=7;
	 x[2][1]=8;
	
	 for(int i=0;i<=x.length;i++) {
		 for(int j=0;j<x[i].length;j++) {
			 System.out.println(x[i][j]);
		 }
	 }

	
}
}
