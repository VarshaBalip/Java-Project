package com.array;

public class Demo {
	
public static void main(String[]args){
	int[]x=new int[3];
	x[0]=1;
	x[1]=2;
	System.out.println(x[0]);
}
}
