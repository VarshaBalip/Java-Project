package com.access_modifier;
//private as a class level modifier is not allowed
public class B {
public void m1() {
	System.out.println("hello");
}
}
