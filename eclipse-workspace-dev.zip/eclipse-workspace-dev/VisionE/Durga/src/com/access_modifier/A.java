package com.access_modifier;
//it is also not allowed
public class A {


//static class B{
	
//}
public static void main(String[] args) {
	System.out.println("hello");
}
}