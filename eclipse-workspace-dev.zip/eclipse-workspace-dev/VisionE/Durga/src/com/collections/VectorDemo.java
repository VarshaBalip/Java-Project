package com.collections;

import java.util.Vector;

public class VectorDemo {
public static void main(String[] args) {
	Vector v=new Vector();
	for(int i=1;i<=10;i++) {
		v.addElement(10);
		
	}
	System.out.println(v.capacity());
	v.addElement(10);
	System.out.println(v.capacity());
	v.addElement(10);
	System.out.println(v.capacity());
	System.out.println(v);
}
}
