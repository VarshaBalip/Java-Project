package com.collections;

import java.util.TreeSet;

public class TreeSetDemo2 {
public static void main(String[] args) {
	TreeSet t=new TreeSet();
	t.add(10);
	t.add(5);
	t.add(2);
	t.add(15);
	t.add(100);
	System.out.println(t);
}
}
