package com.collections;

import java.util.LinkedList;

public class LinkedListDemo {
public static void main(String[] args) {
	LinkedList l=new LinkedList();
	l.add(10);
	l.add(20);
	l.add(30);
	System.out.println(l);
	l.set(0,"pooja");
	l.set(1,"anarthe");
	System.out.println(l);
	l.removeLast();
	System.out.println(l);
	l.addFirst(50);
	System.out.println(l);
}
}
