package com.collections;

import java.util.Comparator;
import java.util.TreeSet;

public class Comparator2A {
public static void main(String[] args) {
	TreeSet t=new TreeSet(new Comparator2B());
	t.add(new StringBuffer("A"));
	t.add(new StringBuffer("Z"));
	t.add(new StringBuffer("K"));
	System.out.println(t);
}
}
