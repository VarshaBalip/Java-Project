package com.collections;

import java.util.Comparator;
import java.util.TreeSet;

public class Comparator3A {
public static void main(String[] args) {
	TreeSet t=new TreeSet(new Comparator3B());
	t.add("S");
	t.add(new StringBuffer("ABC"));
	t.add(new StringBuffer("AA"));
	t.add("XX");
	t.add("ABCD");
	t.add("S");
	System.out.println(t);
}
}
