package com.collections;

public class CompareToMethod {
public static void main(String[] args) {
	System.out.println("A".compareTo("R"));
	System.out.println("R".compareTo("U"));
	System.out.println("A".compareTo("A"));
	System.out.println("M".compareTo("K"));
	System.out.println("C".compareTo("D"));
	System.out.println("D".compareTo("C"));
	System.out.println("A".compareTo(null));
	
}
}
