package com.collections;

import java.util.TreeSet;

public class TreeSetDemo {
public static void main(String[] args) {
	TreeSet t=new TreeSet();
	t.add("A");
	t.add("a");
	t.add("B ");
	t.add("w");
	System.out.println(t);
	//t.add(new Integer(10));
	//t.add(null) ;nullpointerexception
	System.out.println(t);
	
}
}
