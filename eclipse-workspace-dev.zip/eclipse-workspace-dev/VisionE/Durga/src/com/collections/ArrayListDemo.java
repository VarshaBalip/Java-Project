package com.collections;

import java.util.ArrayList;

public class ArrayListDemo {
	public static void main(String[] args) {
		ArrayList l=new ArrayList();
		l.add(10);
		l.add(20);
		l.add("A");
	    l.add(null);
	    System.out.println(l);
	    l.remove(2);
	    System.out.println(l);
	    l.add(2,"p");
	    l.add("n");//it will add at last
	    		System.out.println(l);
	    
}}