package com.collections;

import java.util.Comparator;
import java.util.TreeSet;

public class Comparator1A{
public static void main(String[] args) {
	TreeSet t=new TreeSet(new  Comparator1B());
	t.add("pooja");
	t.add("diyara");
	t.add("sachin");
	t.add("satish");
	t.add("kiara");
	System.out.println(t);//reverse output(descending)
	
}
}
