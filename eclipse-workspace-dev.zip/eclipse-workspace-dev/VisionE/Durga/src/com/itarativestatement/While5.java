package com.itarativestatement;

public class While5 {
public static void main(String[]args){
	int a=10;
	int b=20;
	while(a>b)
		System.out.println("hii");//it is invalid statement
}
}
