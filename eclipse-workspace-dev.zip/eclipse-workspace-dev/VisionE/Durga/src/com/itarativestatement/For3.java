package com.itarativestatement;

public class For3 {
public static void main(String[]args){
	int i=0;
	for(System.out.println("hello");i<3;i++){
		System.out.println("i am diyara");
	}
}
}
