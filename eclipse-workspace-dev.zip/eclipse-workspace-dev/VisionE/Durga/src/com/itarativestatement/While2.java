package com.itarativestatement;

public class While2 {
	public static void main(String[]args){
	int a=0;
		while(a<10)
			System.out.println(++a);
		
	}


}
