package com.itarativestatement;

public class Final_Variable3 {
public static void main(String[]args){
	final int a=10,b=20;
	for(int i=0;a<b;i++){
		System.out.println("hello");
	}
	//System.out.println("hii");unreachable code becoz condition is true
}
}
