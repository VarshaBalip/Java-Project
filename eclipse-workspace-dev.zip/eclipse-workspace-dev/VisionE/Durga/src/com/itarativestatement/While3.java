package com.itarativestatement;

public class While3 {
public static void main(String[]args){
	while(true)
		System.out.println(" i am diyara");
}
}
