package com.itarativestatement;

public class DoWhile3 {
public static void main(String[]args){
	int a=10;
	int b=20;
	do{
		System.out.println("hello");
	}while(a<b);//it will only show the output of do statement
	//	System.out.println("i am pooja");
}
}
