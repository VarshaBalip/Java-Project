package com.itarativestatement;

public class For2 {
public static void main(String[]args){
	for(int i=0;true;i++)
		System.out.println("hello");
}
}
