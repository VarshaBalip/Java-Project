package com.swapping_numbers;

public class A {
public static void main(String[] args) {
	int a=10, b=20;
	
System.out.println("before swapping values are:"+a+"  "+b);

//logic 1
int t=a;
a=b;
b=t;
System.out.println("after swapping logic 1:"+a+"   "+b);

//logic 2-use+ & -without using third variable
a=a+b;//10+20=30
b=a-b;//30-20=10
a=a-b;//30-10=20
System.out.println("after swapping logic 2:"+a+"   "+b);

//logic 3-use* and/without using third variable
//here a&b values should not be zero
a=a*b;//10*20=200
b=a/b;//200/20=10
a=a/b;//200/10=20
System.out.println("after swapping logic 3:"+a+"   "+b);

//logic 4_bitwise XOR
a=a^b;//10^20=30()
b=a^b;//30^20=10()
a=a^b;//30^10=20()
System.out.println("after swapping logic 4:"+a+"   "+b);

//logic 5=single statement
b=a+b-(a=b);//10+20-(10=20)//30-(20)//10

System.out.println("after swapping logic 5:"+a+"   "+b);
}
}
