package com.exception_handling;

import java.io.BufferedReader;

import java.io.FileReader;
import java.io.IOException;

public class G {
public static void main(String[] args) throws IOException {
	try 
		(BufferedReader br=new BufferedReader(new FileReader("input.txt")))
		
		{
		//br=new BufferedReader(new FileReader("output.txt"));
		}
}
}
//FileNotFoundException