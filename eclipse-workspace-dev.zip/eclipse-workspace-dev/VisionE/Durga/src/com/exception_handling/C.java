package com.exception_handling;

import java.io.IOException;
import java.io.PrintWriter;

public class C {
public static void main(String[] args) throws IOException {
	PrintWriter pw=new PrintWriter("lmn.txt");
	pw.println("hello");
	System.out.println(10/0);
}
}
