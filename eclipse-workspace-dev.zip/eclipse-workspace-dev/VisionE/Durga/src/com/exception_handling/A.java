package com.exception_handling;

public class A {
public static void main(String[] args) {
	doStuff();
}

private static void doStuff() {
	// TODO Auto-generated method stub
	doMoreStuff();
}

private static void doMoreStuff() {
	// TODO Auto-generated method stub
	System.out.println("hello");
}
}
