package com.exception_handling;

public class D {
//try{
	//risky code
///	}
//catch(exception e) {
	
//}
//finally {
//	clean up activity
//}
}
//classCastexception
//Object o=new String("pooja);
//String s=(String)o;