package com.exception_handling;

public class E {
public static void main(String[] args) {
	try
	{
		Thread.sleep(10000);
	}
		catch(InterruptedException e) {
			
		}
	}

}
