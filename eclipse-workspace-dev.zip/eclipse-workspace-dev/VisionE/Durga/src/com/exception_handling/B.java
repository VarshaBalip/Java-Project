package com.exception_handling;

public class B {
public static void main(String[] args) {
	doStuff();
}

private static void doStuff() {
	// TODO Auto-generated method stub
	doMoreStuff();
	System.out.println(10/0);
}

private static void doMoreStuff() {
	// TODO Auto-generated method stub
	System.out.println("hello");
}
}
