package com.exception_handling;

public class F {
public static void main(String[] args) {
	//1)//int x=10/0;//arithmetic exception
	
	//2)
//	String s=null;
//	System.out.println(s.length());//nullpointerexception
	
	//3)
//	Thread t=new Thread();
//	t.setPriority(10);
//	t.setPriority(15);//IllegalArgumentException
	
//	4)
//	int i=Integer.parseInt("ten");//NumberFormatException
	//int i=Integer.parseInt(10);
	
	//5)
//	Thread t=new Thread();
//	t.start();
//	t.start();//IllegalThreadStateException

	//6)
	
//	int x=10;
//	assert(x>10);assertion erro


}}
