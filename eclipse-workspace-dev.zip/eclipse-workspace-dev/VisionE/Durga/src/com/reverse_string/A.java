package com.reverse_string;

public class A {
public static void main(String[] args) {
	
	//1 using +(string concatenating)operator
	String str="ABCD";
	String rev="";
	int length=str.length();//4
	for(int i=length-1;i>=0;i--) //3
	{
		rev=rev+str.charAt(i);//D

	}
	System.out.println("reverse string is:"+rev);
}
}
