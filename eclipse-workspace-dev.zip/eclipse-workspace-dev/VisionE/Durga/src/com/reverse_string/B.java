package com.reverse_string;

public class B {
public static void main(String[] args) {
	
	//2.using character array
	String str="ABCD";
	String rev="";
	
	char[]a=str.toCharArray();
	int length=a.length;//4
	
	for(int i=length-1;i>=0;i--)//3
	{
		rev=rev+a[i];
	}
	System.out.println(rev);
}
}
