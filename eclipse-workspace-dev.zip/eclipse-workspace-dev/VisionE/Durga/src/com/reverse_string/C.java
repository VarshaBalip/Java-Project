package com.reverse_string;

public class C {
public static void main(String[] args) {
	//using stringbuffer class
	String str="ABCD";
	StringBuffer sb=new StringBuffer(str);
	System.out.println(sb.reverse());
}
}
