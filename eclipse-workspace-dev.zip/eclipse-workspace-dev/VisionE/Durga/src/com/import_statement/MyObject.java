package com.import_statement;

public class MyObject extends java.rmi.UnicastRemoteObject{

}
