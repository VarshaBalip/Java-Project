package com.import_statement;
import java.util.*;
import java.sql.*;
public class Date {
public static void main(String[] args) {
	Date d=new Date();
	System.out.println(d);
}
}
