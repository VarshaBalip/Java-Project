package com.import_statement;

public class Test {
public static void main(String[] args) {
	String s=new String ("pooja");
	//Student s1=new Student("pooja,10");
}
}
