package com.static_import_statement;
//import static java.lang.math.sqrt;
//import static java.lang.math.*;
//public class Static_Import {
//public static void main(String[] args) {
//	System.out.println(math.sqrt(4));
//	System.out.println(math.max(10,20));
//	System.out.println(math.random());
//}
//}
