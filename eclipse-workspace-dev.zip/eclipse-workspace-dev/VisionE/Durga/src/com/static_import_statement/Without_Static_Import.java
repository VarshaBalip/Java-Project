package com.static_import_statement;

public class Without_Static_Import {
public static void main(String[] args) {
	//System.out.println(math.sqrt());
	//System.out.println(max(10,20));
	//System.out.println(random());
}
}
