package com.static_import_statement;
import static java.lang.System.out;
public class Test {
public static void main(String[] args) {
	out.println("hii");
	out.println("hello");
}
}
