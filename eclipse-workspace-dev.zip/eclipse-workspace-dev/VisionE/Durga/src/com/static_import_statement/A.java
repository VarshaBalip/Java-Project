package com.static_import_statement;
//import static java.lang.Integer.*;//implicit
import static java.lang.Integer.MAX_VALUE;//explicit
import static java.lang.Byte.*;//Byte default MAX_VALUE is 127

public class A {
	//static int MAX_VALUE=999;if we comment out this max value then we will get
	//default static MAX_VALUE is 2147483647
public static void main(String[] args) {
	
	System.out.println(MAX_VALUE);//highest priority goes to explicit static import
}
}//reference to MAX_VALUE is ambiguous
