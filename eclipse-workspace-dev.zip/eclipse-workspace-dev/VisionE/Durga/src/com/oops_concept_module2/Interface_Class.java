package com.oops_concept_module2;

public interface Interface_Class {
public void m1();

}
class  Interface_Class1{
	public void m1() 
	{
		System.out.println("second parent method called");
	}
	
	
}
class B implements Interface_Class{ 

	public void m1() {
	
	}
	
	public static void main(String[] args) {
		A a1=new A();
		a1.m1();
	}
}