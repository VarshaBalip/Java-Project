package com.oops_concept_module2;

import java.io.IOException;

public class P2 {
public static void m1()throws IOException
{
	
}
}
class C2 extends P2 {
	public static void m1() {
		
	}
}