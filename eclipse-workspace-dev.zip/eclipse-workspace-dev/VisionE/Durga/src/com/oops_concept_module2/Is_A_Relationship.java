package com.oops_concept_module2;
//advantages of inheritance:code reusability
public class Is_A_Relationship {
public void m1() {
	System.out.println("parent class method");
}
}
 class A extends Is_A_Relationship{
	public void m2() {
		System.out.println("child class method");
	}
	public static void main(String[] args) {
		A a1=new A();
		a1.m1();
		a1.m2();
	}
}
 
