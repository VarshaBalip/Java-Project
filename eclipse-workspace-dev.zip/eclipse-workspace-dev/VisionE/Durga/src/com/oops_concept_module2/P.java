package com.oops_concept_module2;

public class P {
public Object m1()
{
	return null;
	}
}
class C extends P{
	public String m1()
	{
		return null;
	}
}