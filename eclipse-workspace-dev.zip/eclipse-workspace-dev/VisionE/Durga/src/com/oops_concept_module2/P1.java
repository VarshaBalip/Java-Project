package com.oops_concept_module2;

import java.io.EOFException;

public class P1 {
public static void m1()throws EOFException,InterruptedException {
	
}
}
class C1 extends P1{
	public static void m1()throws EOFException,InterruptedException
	{
	
	}
}