package com.oops_concept_module2;

public class P4 {
public void m1() {
	System.out.println("parent class method");
}
}
class C4 extends P4{
	public void m1() 
	{
		System.out.println("child class method");
	}
	}
class Test {
	public static void main(String[] args) {
		P4 p=new P4();
		p.m1();
		
	}
}