package com.oops_concept_module2;

public class P3 {
public void m1() {
	
}//parent class method does not have static method hence child class can not override static method
}
class C3 extends P3{
	//public static void m1()
	{
		
	}
}