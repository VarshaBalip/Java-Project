package com.oops_concept_module2;

public class HasARelationship {

}
