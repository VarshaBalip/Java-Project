package com.oops_concept_module2;

public class ABCD {
	public void m1(int i)
	{
		
	}
	public void m1(double d) {
		
	}
}
