package com.oops_concept_module2;

public class Without_Inheritance {
//300 methods
//}
//public class Vloan{
//	300 methods
//}
//class Hloan{
//	300 methods
//}
//class ploan{
//	300 methods
}

//public class With_Inheritance{

//250 common methods
//}
//class Vloan extends With_Inheritance{
//	50 specific methods
//}
//class Hloan extends With_Inheritance{
//	50 specific methods
//}