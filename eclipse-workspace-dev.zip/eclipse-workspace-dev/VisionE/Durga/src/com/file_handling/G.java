package com.file_handling;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class G {
public static void main(String[] args) throws IOException {
	FileWriter fw=new FileWriter("pihu.txt");
	BufferedWriter bw=new BufferedWriter(fw);
	bw.write("100");
	bw.newLine();
	bw.write("200");
	bw.write('\n');
	bw.write("300");
	bw.flush();
	bw.close();
	
}
}
