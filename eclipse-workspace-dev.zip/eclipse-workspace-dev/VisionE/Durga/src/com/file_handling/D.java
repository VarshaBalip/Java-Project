package com.file_handling;

import java.io.FileWriter;
import java.io.IOException;

public class D {
public static void main(String[] args) throws IOException {
	FileWriter fw=new FileWriter("diya.txt");
	fw.write("i am diyara");
	fw.write('\n');
	fw.write("i am in nursery class");
	fw.write('\n');
	fw.write("my school name is brilliant grammer high school");
	fw.flush();
	fw.close();
	
}
}
