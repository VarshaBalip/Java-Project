package com.file_handling;

import java.io.File;
import java.io.IOException;

public class A {
public static void main(String[] args) throws IOException {
	File f=new File("sach.txt");
	System.out.println(f.exists());
	f.createNewFile();
	System.out.println(f.exists());
}
}
