package com.file_handling;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class I {
public static void main(String[] args) throws IOException {
	FileWriter fw=new FileWriter("diya.txt");
	PrintWriter pw=new PrintWriter(fw);
	pw.println(100);
	pw.println(200);
	pw.println(true);
	pw.println("pooja");
	pw.flush();
	pw.close();
}

}
