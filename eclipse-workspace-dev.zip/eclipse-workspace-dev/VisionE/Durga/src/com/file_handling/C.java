package com.file_handling;

import java.io.File;

public class C {
public static void main(String[] args) throws Exception {
	int count =0;
	File f=new File("E:\\NEW FOLDER_ECLIPSE CLASS PROGRAM\\File_Handling\\sach");
	String[]s=f.list();
	for(String s1 : s) {
		
		count++;
		System.out.println(s1);
	}
	System.out.println("total number:"+count);
}
}
