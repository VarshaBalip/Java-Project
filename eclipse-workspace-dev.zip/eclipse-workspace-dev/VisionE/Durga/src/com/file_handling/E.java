package com.file_handling;

import java.io.FileWriter;
import java.io.IOException;

public class E {
public static void main(String[] args) throws IOException {
	FileWriter fw=new FileWriter("pihu.txt");
	fw.write("hii");
	fw.write('\n');
	fw.write("hello");
	fw.flush();
	fw.close();
	
}
}
