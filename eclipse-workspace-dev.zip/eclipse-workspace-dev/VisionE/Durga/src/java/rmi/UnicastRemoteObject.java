package java.rmi;

public class UnicastRemoteObject {

}
