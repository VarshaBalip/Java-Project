package com.Loops;

public class ForEachLoop1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//for each loop introduced in version 1.5
		//this loop is only for arrays and collection of object
//syntax(type variable:array){
//	statement}
int a[]=new int[5];
a[0]=1;
a[1]=2;
a[2]=3;
a[3]=4;
a[4]=5;
for(int var:a){
	System.out.println(var);
}
		
	}

}
