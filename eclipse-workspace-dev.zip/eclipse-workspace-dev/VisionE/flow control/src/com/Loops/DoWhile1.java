package com.Loops;

public class DoWhile1 {
public static void main(String[]args){
	boolean b=false;
	do{
		System.out.println("Hello...");
	}while(b);
}
}
