package com.Loops;

public class ForDemo6 {
public static void main(String[]args){
	for(System.out.println("hii");true;System.out.println("Ashu")){System.out.println("i am Varsha");
		}
}
}
