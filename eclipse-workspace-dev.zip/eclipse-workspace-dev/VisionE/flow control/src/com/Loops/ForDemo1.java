package com.Loops;

public class ForDemo1 {
public static void main(String[]args){
	for(int i=1;;){
		System.out.println("hii Ashu");
	}
}
}
