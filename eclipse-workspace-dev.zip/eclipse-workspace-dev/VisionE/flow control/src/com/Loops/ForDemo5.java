package com.Loops;

public class ForDemo5 {
public static void main(String[]args){
	for(System.out.println("hii");true;System.out.println("i am Varsha")){
		System.out.println("How r u");
	}
}
}
