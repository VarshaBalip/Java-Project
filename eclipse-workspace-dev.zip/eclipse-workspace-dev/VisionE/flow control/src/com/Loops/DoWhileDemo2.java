package com.Loops;

public class DoWhileDemo2 {
public static void main(String[]args){
	int a=22;
	int b=44;
	do{
		System.out.println("Hello Sonali");
	}while(a>=b);
}
}
