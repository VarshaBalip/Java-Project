package com.Loops;

public class DoWhileDemo {
public static void main(String[]args){
	
	do{
		System.out.println("Hello Varsha");
	}while(10>20);
}
}
