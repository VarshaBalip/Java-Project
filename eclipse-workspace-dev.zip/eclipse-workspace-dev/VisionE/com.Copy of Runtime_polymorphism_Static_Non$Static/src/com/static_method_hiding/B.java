package com.static_method_hiding;

public class B extends A{
public static void m1(){
	System.out.println("class B static method called");
}
public void m2(){
	System.out.println("class B non static method called");
}
public static void main(String[]args){
	A a1=new B();
	a1.m1();
	a1.m2();
	
}
}
