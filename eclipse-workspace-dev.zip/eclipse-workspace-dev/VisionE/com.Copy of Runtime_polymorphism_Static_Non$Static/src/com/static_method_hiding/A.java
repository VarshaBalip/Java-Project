package com.static_method_hiding;

public class A {
public static void m1(){
	System.out.println("class A static method called");
}
public void m2(){
	System.out.println("class A non static method called");
}
}
