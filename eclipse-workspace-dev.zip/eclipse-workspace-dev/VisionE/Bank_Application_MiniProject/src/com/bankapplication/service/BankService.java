package com.bankapplication.service;

public interface BankService {
public void create_account();
public void view_account_details();
public void withdraw_money();
public void deposit_money();
public void update_account_details();
public void view_account_balance();
	

}
