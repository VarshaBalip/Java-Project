package com.bankapplication.service;

import java.util.Random;
import java.util.Scanner;



import com.bankapplication.model.Account;

public class Bank_Service_Implementation implements BankService{
	
	Account a1=new Account();
	Scanner sc=new Scanner(System.in);
	
	public void createBankAccount() {
		System.out.println("enter your name");
		String name=sc.next();
		ac.setUser_name(name);
		System.out.println("enter your address");
		String address=sc.next();
		ac.setUser_address(address);
		System.out.println("enter you pan number");
		String Pan_no=sc.next();
		ac.setPan_no(Pan_no);
		System.out.println("enter amount to deposit");
		int deposit=sc.nextInt();
		ac.setBalance(deposit);
		//generating random number
		Random random=new Random();
		int accno=random.nextInt();
		ac.setAcc_no(accno);
		System.out.println("your account is created successfully and your account number is:"+accno);
	}

		}
	public void view_account_details(){
		System.out.println("enter your account number");
		int userAccountNumber=sc.nextInt();
		if(a1.getaccount_no()  == userAccountNumber){
			System.out.println("fetching the account details");
			System.out.println(a1.getaccount_no());
			System.out.println(a1.getuser_name());
			System.out.println(a1.getaddress());
			System.out.println(a1.getpan_no());
			System.out.println(a1.getbalance());
			a1.toString();
		}
		else{
			System.out.println("create account first");
		}
		
	}
	public void withdraw_money(){
		System.out.println("enter amount to withdraw");
		int totalAmount=100000,withdraw,deposit;
		int balance=sc.nextInt();
		while(true){
			System.out.println("from which account you have to withdraw money");
			System.out.println("press 1 for saving account");
			System.out.println("press 2 for current account");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:System.out.println("enter money to withdraw:");
			}
		}
				}
	public void deposit_money(){
		
	}
	public void update_account_details(){
		
	}
	}