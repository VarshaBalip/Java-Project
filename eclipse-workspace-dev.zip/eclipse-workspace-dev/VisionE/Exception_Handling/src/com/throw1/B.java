package com.throw1;

public class B {
public static void main(String[] args) {
	throw new InsufficientFundException();
	//System.out.println("hii");
}
}
