package com.throw1;
//we can give exception object explicitily to JVM by 
//using throw keyword

public class A {
public static void main(String[] args) {
	throw new ArithmeticException();
}
}
