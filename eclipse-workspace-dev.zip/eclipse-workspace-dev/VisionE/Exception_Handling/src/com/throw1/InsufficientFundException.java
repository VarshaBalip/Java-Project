package com.throw1;

public class InsufficientFundException extends RuntimeException {

}
