package com.error;
//out of memory error occurs are here
public class B {
public static void main(String[] args) {
	
	StringBuffer sb=new StringBuffer(10000*100000);
}
}
