package com.error;
//stack overflow error are occure here
public class A {

	public void m1(){
		m2();
	}
	public void m2(){
		m1();
	}
	public static void main(String[] args) {
		A a1=new A();
		a1.m1();
	}

}
