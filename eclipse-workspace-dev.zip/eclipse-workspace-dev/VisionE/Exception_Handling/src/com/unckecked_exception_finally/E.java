package com.unckecked_exception_finally;
//finally block is dominated over return sttement
public class E {
public static void main(String[] args) {
	try{
		System.out.println(10/0);
	}
	catch(ArithmeticException e){
		e.printStackTrace();
	}
	finally{
		System.out.println("finally block executed");
	}
}
}
