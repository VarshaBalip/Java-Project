package com.unckecked_exception_finally;
//exception occours and handle and finally block executes
public class B {
public static void main(String[] args) {
	try{
		System.out.println(10/0);
	}
	catch(ArithmeticException e){
		e.printStackTrace();
	}
	finally{
		System.out.println("finally block executes");
	}
}
}
