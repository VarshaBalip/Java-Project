package com.unckecked_exception_finally;

public class C {
	public static void main(String[] args) {
		
	
try{
	System.out.println(10/0);
}
finally{
	System.out.println("finally block executes");
	
}
}
}