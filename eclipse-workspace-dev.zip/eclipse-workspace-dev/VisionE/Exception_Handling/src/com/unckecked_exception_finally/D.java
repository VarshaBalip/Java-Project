package com.unckecked_exception_finally;

public class D {
public static void main(String[] args) {
	int i=10;
	while(i==10){
		System.out.println("while loop executed");
		return;
	}
	System.out.println("hii");
}
}
