package com.unckecked_exception_finally;
//exception is occurs and not handle then still finally block execute
public class A {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     try{
    	 System.out.println(10/0);
     }
     catch(NullPointerException n){
    	 n.printStackTrace();
     }
     finally{
    	 System.out.println("finally block executes");
     }
     System.out.println("hii");
	}

}
