package com.unckecked_exception_finally;

public class F {
public static void main(String[] args) {
	try{
		System.out.println(10/0);
	}
	catch(ArithmeticException e){
		e.printStackTrace();
		System.exit(0);//it will shut down JVM directly
}
	finally{
		System.out.println("finally block executes");
	}
}
}
