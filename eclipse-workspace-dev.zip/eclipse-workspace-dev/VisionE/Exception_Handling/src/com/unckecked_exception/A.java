package com.unckecked_exception;
//exception is unwanted event causes the abnormal termination of a program
public class A {
public static void main(String[] args) {
	System.out.println(10/0);
	//after the exception jvm will not check the remaining line of code
	System.out.println("Hii");
}
}
//output is ArithmeticException