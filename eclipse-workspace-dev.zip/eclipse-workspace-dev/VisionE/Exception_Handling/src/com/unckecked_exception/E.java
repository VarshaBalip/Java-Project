package com.unckecked_exception;
//null pointer exception
public class E {
public static void main(String[] args) {
	String s=null;
	try{
		s.charAt(0);
	}
	catch(NullPointerException n){
		n.printStackTrace();
	}
	System.out.println("Hii");
}
}
