package com.unckecked_exception;

public class H {
public static void main(String[] args) {
	try{
		System.out.println(10/0);
	}
	catch(ArithmeticException e){
		System.out.println("catch 1 block execute");
	}
	catch(Exception e){
		System.out.println("catch 2 block execute");
	}//exception is already handle by 1st catch block then there is
	//no need to execute 2nd block
}
}
