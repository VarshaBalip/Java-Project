package com.unckecked_exception;

public class I {
public static void main(String[] args) {
	try{
		System.out.println(10/0);
	}
	catch(NullPointerException e){
		System.out.println("null pointer exception catch");
	}
	catch(ArithmeticException e){
		System.out.println("arithmetic exception catch");
	}
	System.out.println("hii");
}
}
