package com.unckecked_exception;
//classcastexception
public class F {
public static void main(String[] args) {
	Object o=new Integer(10);
	try{
		String s1=(String )o;
	}
	catch(ClassCastException a){
		a.printStackTrace();
	}
	System.out.println("Hii");
}
}
