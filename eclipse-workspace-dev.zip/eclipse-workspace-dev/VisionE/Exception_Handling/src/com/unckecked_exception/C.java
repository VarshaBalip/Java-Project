package com.unckecked_exception;

public class C {
public static void main(String[] args) {
	try{
		System.out.println(10/0);
	}
	catch(ArithmeticException e){
		e.printStackTrace();
		//printStackTrace gives o/p
		//1) name of exception
		//2)description of exception
		//3)line number of exception
		System.out.println("hii");
	}
}
}
