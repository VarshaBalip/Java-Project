package com.unckecked_exception;
//if we give arithmetic exception and we want to print null pointer exception 
//then jvm is shows a arithmetic exception only
public class G {
public static void main(String[] args) {
	try{
		System.out.println(10/0);
	}
	catch(NullPointerException n){
		System.out.println(n.toString());
	}
	System.out.println("Hii");
}
}
