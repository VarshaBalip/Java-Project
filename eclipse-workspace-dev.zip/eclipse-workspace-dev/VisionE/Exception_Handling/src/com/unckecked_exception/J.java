package com.unckecked_exception;

public class J {
public static void main(String[] args) {
	try{
		System.out.println(10/0);
	}
	catch(Exception e){
		System.out.println(e.toString());
	}
	
	//it will give an error and tell us already exception
	//handle by 1st catch block
	//catch(ArithmeticException e1){
		//System.out.println(e1.toString());
	//}
}
}
