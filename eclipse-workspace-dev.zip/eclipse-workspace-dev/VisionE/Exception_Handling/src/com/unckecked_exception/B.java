package com.unckecked_exception;
//we can handle exception by using try and catch block
//if we want to handle exception we need to put risky code inside a try block
//and we need to catch exception in catch block
public class B {
public static void main(String[] args) {
	try{
		System.out.println(10/0);
	}
	catch(ArithmeticException e){
		System.out.println("exception is catched");
	}
	//once we handled the exception jvm will run below line of code
	System.out.println("Hii");
	System.out.println("I am Varsha");
}
}
