package com.unckecked_exception;
//inside try and catch block we can handle only one examples
public class D {
public static void main(String[] args) {
	try{
		System.out.println(10/0);
		String s=null;
		s.toLowerCase();
	}
	catch(Exception e){
		e.printStackTrace();
	}
	System.out.println("hii");
}
}
