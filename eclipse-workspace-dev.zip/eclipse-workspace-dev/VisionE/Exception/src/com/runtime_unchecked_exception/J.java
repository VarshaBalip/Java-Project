package com.runtime_unchecked_exception;

public class J {
public static void main(String[] args) {
	try{
		System.out.println(10/0);
	}catch(Exception e){//parent of arithmetic exception
		System.out.println(e.toString());
	//}//already parent class (exception)is show the arithmetic exception then it will not go for second
	//line also
	//catch(ArithmeticException a){
	//	System.out.println(a.toString());
	}
}
}
