package com.runtime_unchecked_exception;

public class D {
public static void main(String[] args) {
	System.out.println(10/0);
	String s=null;
	s.toLowerCase();//Exception in thread "main" java.lang.ArithmeticException: / by zero
	//at com.runtime_unchecked_exception.NullPointer_Exception.main(NullPointer_Exception.java:5)

}
}
