package com.runtime_unchecked_exception;

//inside a try block we can handlle only one exception
public class E {
	public static void main(String[] args) {
		//java.lang.ArithmeticException: / by zero
		//at com.runtime_unchecked_exception.E.main(E.java:7)
		try {
			System.out.println(10 / 0);
		} catch (ArithmeticException a) {
			a.printStackTrace();
		}
		//java.lang.NullPointerException
	//	at com.runtime_unchecked_exception.E.main(E.java:13)
		try {
			String s = null;// this is not risky code
			s.toLowerCase();
		}

		catch (NullPointerException e) {
			e.printStackTrace();
		}
		System.out.println("pooja");

	}
}
