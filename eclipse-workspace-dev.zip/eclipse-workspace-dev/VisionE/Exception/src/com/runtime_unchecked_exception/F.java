package com.runtime_unchecked_exception;

public class F {
public static void main(String[] args) {
	Object o=new Integer(10);
	try{
	String s=(String)o;
	}
	catch(ClassCastException a){
		a.printStackTrace();
	}
	System.out.println("pooja");
	//type casting(object class is casted into string ie downcasting)
	// java.lang.Integer cannot be cast to java.lang.String
	//int i=10;
	//short s=(short) i;//type casting
}
}
