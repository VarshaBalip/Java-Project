package com.runtime_unchecked_exception;

public class I {
public static void main(String[] args) {
	try{
		System.out.println(10/0);
	}
	catch(NullPointerException e){
	System.out.println("null pointer exception");
	}catch(Exception a){
		System.out.println("exception block executed");
	}
	System.out.println("Varsha");
}
}
