package com.runtime_unchecked_exception;

public class K {

}
