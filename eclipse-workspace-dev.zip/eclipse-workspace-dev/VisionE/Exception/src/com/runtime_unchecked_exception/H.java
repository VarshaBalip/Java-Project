package com.runtime_unchecked_exception;

public class H {
public static void main(String[] args) {
	try{
		System.out.println(10/0);
	}catch(ArithmeticException e){
		System.out.println("1st catch block executed");//here only first catch block executed 
	}catch(Exception e){
		System.out.println("2nd catch block executed");
	}
}
}
