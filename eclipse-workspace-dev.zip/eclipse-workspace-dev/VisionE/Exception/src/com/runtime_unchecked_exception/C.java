package com.runtime_unchecked_exception;

public class C {
public static void main(String[] args) {
	try{
		System.out.println(10/0);
	}catch(ArithmeticException a){
		a.printStackTrace();
		//1) it will show the name of exception
		//2)it will show description of exception
		//3)it will show at which number line you get exception
		System.out.println(a.getMessage());//it will show description
		System.out.println(a.toString());//it will show at com.runtime_unchecked_exception.C.main(C.java:6)

	}
}
}
