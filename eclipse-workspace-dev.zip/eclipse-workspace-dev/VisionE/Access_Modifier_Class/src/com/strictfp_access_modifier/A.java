package com.strictfp_access_modifier;

public class A {
public static void main(String[]args){
	System.out.println(13324.53252*2537/23);
}
}
