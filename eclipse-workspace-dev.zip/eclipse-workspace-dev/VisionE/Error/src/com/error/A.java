package com.error;
//Stack overflow error occur are here
public class A {
public void m1(){
	m2();
}
public void m2(){
	m1();
}
public static void main(String[] args) {
	A a=new A();
	a.m1();
}
}
