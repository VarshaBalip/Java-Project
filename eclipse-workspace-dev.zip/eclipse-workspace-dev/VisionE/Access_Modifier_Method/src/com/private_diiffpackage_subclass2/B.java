package com.private_diiffpackage_subclass2;//using extends keyword
//import com.private_diiffpackage_subclass2.A;
//public class B extends A{
//public static void main(String[]args){
//	A a1=new A();
//	a1.m1();
//	B b1=new B();
//	b1.m1();
//	A a2=new B();
//	a2.m1();
//	here we cant access class fron diifferent package and different class
//}
//}
