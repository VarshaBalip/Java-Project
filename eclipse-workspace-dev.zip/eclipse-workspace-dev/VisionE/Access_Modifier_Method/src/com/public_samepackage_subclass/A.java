package com.public_samepackage_subclass;

public class A {
public void m1(){
	System.out.println("class A method called");
}
}
