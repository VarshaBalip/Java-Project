package com.final_diffpackage_subclass1;

public class A {
	
final void m1(){
	System.out.println("class A method called");
}
}
