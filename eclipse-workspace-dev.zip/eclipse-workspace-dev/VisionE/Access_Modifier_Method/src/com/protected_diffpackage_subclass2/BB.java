package com.protected_diffpackage_subclass2;
import com.protected_diffpackage_subclass1.AA;
public class BB extends AA {
public static void main(String[]args){
	AA a1=new AA();//parent object parent reference
	AA a2=new BB();//parent reference child object
	BB b1=new BB();
	//a1.m1();not allowed
	//a2.m1();not allowed
	b1.m1();
}
}
