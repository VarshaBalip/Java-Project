package com.protected_samepackage_nonsubclass;

public class A {
	protected void m1(){
		System.out.println("class A method called");
	}
}
