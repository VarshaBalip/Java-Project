package com.final_samepackage_nonsubclass;

public class B {
public static void main(String[]args){
	A a1=new A();
	a1.m1();
}
}
