package com.final_diffpackage_subclass2;

import com.public_diffpackage_nonsubclass1.A;

public class B extends A {
public static void main(String[]args){
	A a1=new A();
	a1.m1();
}
}
