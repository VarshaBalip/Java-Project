package com.default_diffpackage_nonsubclass1;

 class A {
void m1(){
	System.out.println("class A method called");
}
}
