package com.default_diffpackage_subclass2;
//import com.default_diffpackage_subclass2.A;
//public class B extends A {
//public static void main(String[]args){
//	A a1=new A();
//	a1.m1();
//} 
//}
//not allowed