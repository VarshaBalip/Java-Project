package com.private_samepackage_nonsubclass;//without extends keywords

public class B {
public static void main(String[]args){
//	A a1=new A();
//	a1.m1();
//	B b1= new B();here we can not access class from same package _non sub class 
//	b1.m1();
//	A a2=new B();
//	a2.m1();
//	
}
}
