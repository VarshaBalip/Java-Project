package com.default_samepackage_nonsubclass;

public class BB {
public static void main(String[]args){
	AA a1=new AA();
	a1.m1();

	
}
}
