package com.public_sameclass;

public class A {
public void m1(){
	System.out.println("class A method called");
}
public static void main(String[]args){
	A a1=new A();
	a1.m1();
}
}
