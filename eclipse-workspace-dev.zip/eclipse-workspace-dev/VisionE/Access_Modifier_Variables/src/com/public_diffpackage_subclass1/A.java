package com.public_diffpackage_subclass1;

public class A {
public float f=12.4225f;
}
