package com.public_samepackage_subclass;

public class A {
public short s=15;
}
