package com.default_samepackage_nonsubclass;

public class A {
long l=30l;

}
