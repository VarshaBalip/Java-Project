package com.private_samepackage_nonsubclass;

public class A {
private short s=103;
}
