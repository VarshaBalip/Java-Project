package com.private_diffpackage_subclass2;
import com.private_diffpackage_subclass1.A;
public class B extends A {
public static void main(String[]args){
	A a1=new A();
	//System.out.println(a1.l);not allowed
}
}
