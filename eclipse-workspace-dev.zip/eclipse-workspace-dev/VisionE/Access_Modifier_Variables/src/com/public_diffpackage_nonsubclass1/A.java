package com.public_diffpackage_nonsubclass1;

public class A {
public long l=23l;
}
