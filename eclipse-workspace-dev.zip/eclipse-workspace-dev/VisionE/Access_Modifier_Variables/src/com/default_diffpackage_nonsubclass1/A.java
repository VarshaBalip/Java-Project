package com.default_diffpackage_nonsubclass1;

public class A {
float f=10.253f;
}
