package com.public_samepackage_nonsubclass;

public class A {
public byte b=19;
}
