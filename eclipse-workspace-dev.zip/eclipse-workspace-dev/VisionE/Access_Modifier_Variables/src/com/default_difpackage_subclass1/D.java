package com.default_difpackage_subclass1;

public class D {
short s=50;
}
