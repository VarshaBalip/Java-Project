package com.private_diffpackage_subclass1;

public class A {
private long l=1233l;

}
