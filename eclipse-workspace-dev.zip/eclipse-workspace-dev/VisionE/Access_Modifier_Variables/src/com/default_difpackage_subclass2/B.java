package com.default_difpackage_subclass2;
import com.default_difpackage_subclass1.A;
public class B {
public static void main(String[]args){
	A a1=new A();
	//System.out.println(a1.s);not allowed
}
}
