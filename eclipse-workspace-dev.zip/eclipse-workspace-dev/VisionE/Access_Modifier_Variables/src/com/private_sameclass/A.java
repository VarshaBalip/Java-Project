package com.private_sameclass;

public class A {
private int i=10;
public static void main(String[]args){
	A a1=new A();
	System.out.println(a1.i);
}
}
