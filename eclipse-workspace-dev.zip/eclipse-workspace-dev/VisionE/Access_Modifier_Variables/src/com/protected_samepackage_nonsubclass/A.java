package com.protected_samepackage_nonsubclass;

public class A {
protected double d=50;
}
