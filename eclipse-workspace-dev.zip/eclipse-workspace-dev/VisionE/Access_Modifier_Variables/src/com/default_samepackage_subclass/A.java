package com.default_samepackage_subclass;

public class A {
 byte b=20;

}

