package com.buffered_reader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class A {
public static void readFromFile() throws IOException {
	FileReader f=new FileReader("E:\\NEW FOLDER_ECLIPSE CLASS PROGRAM\\File_Handling\\ABC.txt");
	BufferedReader b=new BufferedReader(f);
	String readLine=b.readLine();
	//System.out.println(readLine);
	while(readLine!=null) {
		System.out.println(readLine);
		readLine=b.readLine();
	}
f.close();
}
   

public static void main(String[] args) throws IOException {
	readFromFile();

}}
