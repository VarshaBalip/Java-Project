package com.filehandling;

import java.io.File;
import java.io.IOException;


//we can use throws keywords for checked exception only
//throws keyword deligating exception handling to its called
public class Demo{
	public static void createFile() throws IOException{
	File f=new File("E:\\pooja.txt");
//		if(f.createNewFile()) {
//			System.out.println("file is created");
//		}
//		else {
//			System.out.println("file is not created");
//		}
		boolean canRead=f.canRead();
		System.out.println(canRead);
		System.out.println(f.canWrite());
		System.out.println(f.canExecute());
		System.out.println(f.exists());
	}
	public static void main(String[] args) throws IOException {
		createFile();
	}
}