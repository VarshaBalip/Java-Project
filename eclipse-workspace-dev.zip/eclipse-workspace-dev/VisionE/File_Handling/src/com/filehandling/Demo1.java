package com.filehandling;

import java.io.FileWriter;
import java.io.IOException;

public class Demo1 {
public static void writeIntoFile(){
	try{
	FileWriter f=new FileWriter("E:\\pooja.txt");
	String text="hii good morning";
	f.write(text);
  f.close();
	}
	catch(IOException e) {
		e.printStackTrace();
	}
}
public static void main(String[] args) {
	writeIntoFile();
}
}
