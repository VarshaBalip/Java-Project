package com.print_writer;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class A {
public static void main(String[] args) throws FileNotFoundException {
	PrintWriter p=new PrintWriter("E:\\NEW FOLDER_ECLIPSE CLASS PROGRAM\\File_Handling\\g.txt");
	p.write("character type data");
   // p.write("\n");
	p.println();
	p.print(10.0f);
	p.close();
}
}
