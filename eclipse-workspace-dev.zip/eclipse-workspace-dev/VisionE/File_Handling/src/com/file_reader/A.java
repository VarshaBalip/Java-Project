package com.file_reader;

import java.io.FileReader;
import java.io.IOException;

public class A {
public static void readFromFile() throws IOException {
	FileReader f=new FileReader("E:\\NEW FOLDER_ECLIPSE CLASS PROGRAM\\File_Handling\\RST");
    int read=f.read();
	//System.out.println((char)read);
	while(read!=-1) {
		//System.out.println((char)read);
		System.out.print((char)read);//here we delete ln hence we get o/p in same line
		read=f.read();
	//	f.close();//it will get exception that is connection closed
	}

	f.close();
}
public static void main(String[] args) throws IOException {
	readFromFile();
}
}
//if we want one by one character we have to write println
//if we want character simultaneously we have to write only print