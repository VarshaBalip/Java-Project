package com.buffered_writer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;


public class A {
public static void writeintoFile() throws IOException {
FileWriter f=new FileWriter("E:\\NEW FOLDER_ECLIPSE CLASS PROGRAM\\File_Handling\\f.txt");
	BufferedWriter br=new BufferedWriter(f);
	br.write("ABCD");
	br.newLine();
	br.write("EFGH");
	br.close();
	f.close();
}
public static void main(String[] args) throws IOException {
	writeintoFile();
}
}
