package com.file_writer;
import java.io.FileWriter;
import java.io.IOException;

public class A {
public static void WriteintoFile() throws IOException {
	//FileWriter f=new FileWriter("E:\\NEW FOLDER_ECLIPSE CLASS PROGRAM\\File_Handling\\XYZ");
	//f.write("ABCDEFGH");
	//f.close();
	FileWriter f1=new FileWriter("E:\\NEW FOLDER_ECLIPSE CLASS PROGRAM\\File_Handling\\RST");
	f1.write("pooja");
	f1.write("hii");
	f1.write("\n");
	f1.write("how are you");
	f1.close();
}
public static void main(String[] args) throws IOException{
	WriteintoFile();
}

}

