package com.file_creation;

import java.io.File;
import java.io.IOException;

public class A {
public static void createFile() throws IOException {
	File f=new File("xyz.txt");
	boolean createNewFile=f.createNewFile();
	System.out.println(createNewFile);
	if(f.createNewFile()) {
		System.out.println("file is created");
	}
	else {
		System.out.println("file is not created");
	}
}
public static void main(String[] args) throws IOException {
	createFile();
}
}
