package com.superinheritance;

public class Child extends Parent{
public Child(){
	super();
	System.out.println("Child method constructor");
}
public static void main(String[]args){
	Child c1=new Child();
	Parent p1=new Parent();
	Parent p2=new Child();
}
}
