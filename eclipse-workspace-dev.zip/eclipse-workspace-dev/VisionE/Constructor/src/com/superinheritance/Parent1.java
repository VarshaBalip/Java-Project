package com.superinheritance;

public class Parent1 {
int i=10;
}
