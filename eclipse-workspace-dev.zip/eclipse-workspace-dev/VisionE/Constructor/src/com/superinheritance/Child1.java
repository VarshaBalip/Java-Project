package com.superinheritance;

public class Child1 extends Parent1 {
	
	int i=50;
	
public void m1(){
	System.out.println("value of super:"+super.i);
}
public static void main(String[]args){
	Child1 c1=new Child1();
	c1.m1();
	
	
}
}
