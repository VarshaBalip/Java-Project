package com.superinheritance;

public class Parent2 {
	public void m1(){
		System.out.println("parent 2 method");
	}
}
