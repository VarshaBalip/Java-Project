package com.superinheritance;

public class Child2 extends Parent2 {
public void m1(){
	System.out.println("child 2 method");
}
public void m2(){
	super.m1();
	this.m1();
}
public static void main(String[]args){
	Child2 c1=new Child2();
	c1.m2();
}
}
