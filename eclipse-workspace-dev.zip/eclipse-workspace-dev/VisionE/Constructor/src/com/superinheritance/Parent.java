package com.superinheritance;

public class Parent {
public Parent (){
	super();
	System.out.println("parent method constructor");
}
}
