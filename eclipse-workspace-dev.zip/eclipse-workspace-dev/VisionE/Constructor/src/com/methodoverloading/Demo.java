package com.methodoverloading;

public class Demo {
int a;
int b;
int c;
int d;
public Demo(){
	super();
	System.out.println(" no args");
}
public Demo(int a){
	super();
	this.a=a;
	System.out.println("1 args");
}
public Demo(int a,int b){
	super();
	this.a=a;
	this.b=b;
	System.out.println("2 args");
	
}
public Demo(int a,int b,int c){
	super();
	this.a=a;
	this.b=b;
	this.c=c;
	System.out.println("3 args");
}
public Demo(int a,int b,int c,int d){
	super();
	this.a=a;
	this.b=b;
	this.c=c;
	this.d=d;
	System.out.println("4 args");
}
public static void main(String[]args){
	Demo d=new Demo();
	Demo d1=new Demo(10);
	Demo d2=new Demo(10,20);
	Demo d3=new Demo(10,20,30);
	Demo d4=new Demo(10,20,30,40);
	
	
	
}
}
