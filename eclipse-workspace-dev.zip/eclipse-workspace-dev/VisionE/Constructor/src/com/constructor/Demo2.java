package com.constructor;

public class Demo2 {
int i;
public Demo2(int i) {
	super();
	this.i = i;
}
public static void main(String[]args){
	Demo2 i1=new Demo2(10);
	Demo2 i2=new Demo2(20);
	Demo2 i3=new Demo2(30);
	System.out.println(i1.i);
	System.out.println(i2.i);
	System.out.println(i3.i);
}
}
