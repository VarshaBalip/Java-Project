package com.constructor;


public class Demo {
	int i;
	public Demo(int i) {
		super();
		this.i = i;
	}
	public static void main(String[]args){
		Demo d=new Demo(5);
		System.out.println(d.i);
		}
}
