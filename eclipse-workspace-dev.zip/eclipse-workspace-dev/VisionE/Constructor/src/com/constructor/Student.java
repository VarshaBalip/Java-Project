package com.constructor;
//to perform initialization of object
public class Student {
int rollNo;
String name;
String surName;
public Student(int rollNo, String name, String surName) {
	super();
	this.rollNo = rollNo;
	this.name = name;
	this.surName = surName;
}


void display(){
	System.out.println(rollNo+" "+name+" " +surName);
	}
	public static void main(String[]args){
		Student s1=new Student(1,"Varsha","Anekar");
		Student s2=new Student(2,"Asha","Wadekar");
		s1.display();
		s2.display();
	}
}

