package com.constructor_this.demo;

public class Demo {
int a;
int b;
int c;
public Demo(){
	this(10);
	System.out.println("no args constructot");
}
public Demo(int a){
	this(20,30);
	this.a=a;
	System.out.println("1 arg constructor");
}
public Demo(int a,int b){
	this(40,50,60);
	this.a=a;
	this.b=b;
	System.out.println("2 arg constructor");
}
public Demo(int a,int b,int c){
	
	this.a=a;
	this.b=b;
	this.c=c;
	System.out.println("3 arg constructor");
}
public static void main(String[]args){
	Demo d1=new Demo();
	
	
}
}
