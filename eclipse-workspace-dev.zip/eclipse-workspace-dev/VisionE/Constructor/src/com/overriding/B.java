package com.overriding;

public class B {
public B(){
	super();
}
}
