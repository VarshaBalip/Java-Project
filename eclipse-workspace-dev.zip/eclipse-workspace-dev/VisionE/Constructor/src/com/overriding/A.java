package com.overriding;
//to achieve constructor overriding signature should be same
//but is not possible in constructor
//hence we can say constructor overriding is not possible
public class A {
public A(){
	super();
}
}
