package com.codeswitch;

public class string {
	public static void main(java.lang.String[]args){
		System.out.println("welcome varsha");
	}

}
