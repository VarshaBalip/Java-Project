package com.vision;

public class ConditionDemo4 {

	public static void main(String[] args) {
		float f1 = (12.437323f);
		float f2 = (5.3757768f);
		if (f1 < f2) {
			System.out.println("value of float f1 is greater than f2");
		} else {
			System.out.println("value of float f1 is less than f2");
		}
	}

}
