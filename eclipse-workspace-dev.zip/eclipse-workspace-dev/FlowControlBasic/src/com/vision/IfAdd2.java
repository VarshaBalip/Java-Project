package com.vision;

public class IfAdd2 {

	public static void main(String[] args) {
		int a=2;
		int b=3;
		if(a+b==10){
			System.out.println("additon is correct");
		}else{
			System.out.println("addition is wrong");
		}
	}

}
