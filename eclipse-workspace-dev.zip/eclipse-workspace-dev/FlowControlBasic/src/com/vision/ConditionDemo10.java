package com.vision;

public class ConditionDemo10 {

	public static void main(String[] args) {
		int a = 11;
		int b = 8;
		int c = (a | b);
		if (c == 1011) {
			System.out.println("value of c is 11");

		} else {
			System.out.println("value of c is wrong");
		}
	}

}
