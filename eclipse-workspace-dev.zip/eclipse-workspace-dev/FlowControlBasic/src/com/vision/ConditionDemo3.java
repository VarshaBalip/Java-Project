package com.vision;

public class ConditionDemo3 {
public static void main(String[]args){
	
	String s="varsha";
	String e="balip";				
	if (s+e!=null)
	{		
		System.out.println("varsha balip");		
	}
	else
	{
		System.out.println("name is wrong");
	}	
}
}
