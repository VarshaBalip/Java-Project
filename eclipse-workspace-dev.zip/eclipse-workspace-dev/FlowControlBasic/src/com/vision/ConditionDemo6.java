package com.vision;

public class ConditionDemo6 {

	public static void main(String[] args) {
		int a = 10;
		int b = 20;
		int c = 30;
		int d = 40;
		boolean b1 = (a < b);
		boolean b2 = (c > d);
		if (b1 && b2) {
			System.out.println("value of boolean is true");
		} else {
			System.out.println("value of boolean is false");
		}
	}

}
