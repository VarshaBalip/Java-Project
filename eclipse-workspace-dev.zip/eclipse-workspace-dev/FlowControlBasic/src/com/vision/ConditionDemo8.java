package com.vision;

public class ConditionDemo8 {

	public static void main(String[] args) {
		int a=10;
		int b=15;
		
		boolean c=!(a<b);
		if (c=true){
			
		System.out.println("value of c is true");

		}
			
		else{
			System.out.println("value of c is false");
		}
	}

}
