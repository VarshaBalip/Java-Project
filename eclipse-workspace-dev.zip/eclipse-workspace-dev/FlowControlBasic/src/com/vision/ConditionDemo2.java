package com.vision;

public class ConditionDemo2 {
	public static void main(String[] args) {
		String s = ("varsha");
		String d = ("sonali");

		if (s + d != null) {
			System.out.println("varsha sonali");

		} else {
			System.out.println("varsha balip");
		}

	}
}
