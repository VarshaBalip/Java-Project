package com.vision;

public class IfAdd1 {

	public static void main(String[] args) {
		int a=10;
		int b=2;
		if(a+b==12){
			System.out.println("addition is correct");
		}else{
			System.out.println("addition is wrong");
		}
	}

}
