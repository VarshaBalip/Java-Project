package com.loops;

public class ForLoop1 {

	public static void main(String[] args) {
		for(int num=1;num<=10;num++){
			System.out.println(num);
			
		}
	}

}
