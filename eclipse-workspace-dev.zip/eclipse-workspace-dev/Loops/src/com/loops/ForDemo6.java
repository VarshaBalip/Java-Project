package com.loops;

public class ForDemo6 {

	public static void main(String[] args) {
		for(System.out.println("hii");true;System.out.println("pari")){System.out.println("i am purva");
		}
	}

}
