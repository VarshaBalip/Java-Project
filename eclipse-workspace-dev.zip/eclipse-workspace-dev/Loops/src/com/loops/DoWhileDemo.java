package com.loops;

public class DoWhileDemo {

	public static void main(String[] args) {		
		do{
			System.out.println("Hello varsha");
		}while(10>20);
	}
}
