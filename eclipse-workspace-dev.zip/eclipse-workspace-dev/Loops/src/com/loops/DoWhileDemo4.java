package com.loops;

public class DoWhileDemo4 {

	public static void main(String[] args) {
		boolean b=false;
		do{
			System.out.println("i am Ashvik Anekar");
		}while(b);
	}

}
