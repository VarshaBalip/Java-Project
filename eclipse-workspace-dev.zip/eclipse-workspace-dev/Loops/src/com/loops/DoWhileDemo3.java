package com.loops;

public class DoWhileDemo3 {

	public static void main(String[] args) {
		boolean b=true;
		do{
			System.out.println("i am varsha");
		}while(b);
	}

}
