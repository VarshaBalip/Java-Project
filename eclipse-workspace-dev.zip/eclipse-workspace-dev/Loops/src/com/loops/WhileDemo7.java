package com.loops;

public class WhileDemo7 {

	public static void main(String[] args) {
		boolean b=true;
		int a=0;
		while(b){
			System.out.println(++a);
			if(a==10000){
				break;
			
		}
	}
	}

}
