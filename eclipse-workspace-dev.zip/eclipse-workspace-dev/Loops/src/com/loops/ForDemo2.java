package com.loops;

public class ForDemo2 {

	public static void main(String[] args) {
		for(;;){
			System.out.println("i am varsha");
		}
	}

}
