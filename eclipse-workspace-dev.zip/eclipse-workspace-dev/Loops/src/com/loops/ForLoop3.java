package com.loops;

public class ForLoop3 {

	public static void main(String[] args) {
		for(int a=0;a<=10;a++){
			System.out.println("Hello");
			System.out.println("Adhika");
		}
	}

}
