package com.loops;

public class WhileDemo1 {

	public static void main(String[] args) {
//		if(true)
//		System.out.println("hii");
//	while(true)
//		System.out.println("hii");
	if(true){
		int a=1;
		System.out.println(++a);
	}
	while(true){
		int b=2;
	System.out.println(++b);
	}

	}

}
