package com.loops;

public class DoWhile2 {

	public static void main(String[] args) {
		boolean b=false;
		do {
			System.out.println("i am Varsha");
			}
			while(b);
	}

}
