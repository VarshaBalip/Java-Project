
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class A {

	public static void main(String[] args) throws ClassNotFoundException, SQLException
	{
		//register the driver class
		Class<?> class1 = Class.forName("com.mysql.cj.jdbc.Driver");
		
		System.out.println(class1);
		//get connection object
		
		Connection connection = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/student_details", "root", "Vision@2023");
		
		//get statement
		Statement statement = connection.createStatement();
		
		String sql = "create table Student(ROLL_NO int primary key, NAME varchar(50), STANDARD varchar(50))"; 
		
		//passing sql queries/execute queries
		statement.execute(sql);		
		
		//close database connection
		connection.close();
		System.out.println("Student table created successfully");
	}	
}
