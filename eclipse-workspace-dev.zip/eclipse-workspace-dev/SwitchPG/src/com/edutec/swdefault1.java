package com.edutec;

public class swdefault1 {
	public static void main(String[] args) {
		int a = 10;
		switch (a) {
		case 0: {
			System.out.println("case 0 is executed");
		}
		case 1: {
			System.out.println("case 1 is executed");
		}
		case 2: {
			System.out.println("case 2 is executed");
		}
		default: {
			System.out.println("defalut case is executed");
		}
		}
	}
}
