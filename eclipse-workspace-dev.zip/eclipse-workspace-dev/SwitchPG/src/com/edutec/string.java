package com.edutec;

public class string {
	public static void main(java.lang.String[]args){
		System.out.println("welcome Varsha");
	}
}