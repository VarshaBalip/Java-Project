package com.edutec;

public class sw1 {
		public static void main(String[] args) {
			int a = 0;
			switch (a) {
			case 0: {
				System.out.println("case 0 executed");
			}
			case 1: {
				System.out.println("case 1 executed");
			}
			case 2: {
				System.out.println("case 2 executed");
			}
			}

		}
	}
