package com.visionedutech;

public class Demo2 {

	public static void main(String[] args) {
		int a=56;
		int b=34;
		
		if(a>b);{
		System.out.println("a is grater than b");
		}
		if(a<b);{
			System.out.println("a is less than b");			
		}
	}

}
