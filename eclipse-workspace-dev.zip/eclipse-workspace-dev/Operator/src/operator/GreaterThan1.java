package operator;

public class GreaterThan1 {
	public static void main(String[] args) {
		int a = 20;
		int b = 50;
		boolean c = (a > b);
		System.out.println(c);
	}
}
