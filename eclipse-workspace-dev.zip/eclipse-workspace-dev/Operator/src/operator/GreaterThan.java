package operator;

public class GreaterThan {
	public static void main(String[] args){
		int a=20;
		int b=10;
		boolean c=(a>b);
		System.out.println(c);
	}
}
