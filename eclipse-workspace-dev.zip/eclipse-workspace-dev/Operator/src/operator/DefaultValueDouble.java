package operator;

public class DefaultValueDouble {
	double d;

	public static void main(String[] args) {

		DefaultValueDouble s = new DefaultValueDouble();
		System.out.println(s.d);
	}

}
