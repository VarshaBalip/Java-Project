package operator;

public class DefaultValueLong {
	long l;

	public static void main(String[] args) {

		DefaultValueLong y = new DefaultValueLong();
		System.out.println(y.l);

	}

}
