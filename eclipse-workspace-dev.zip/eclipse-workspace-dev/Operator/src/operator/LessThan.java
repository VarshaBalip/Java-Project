package operator;

public class LessThan {
	public static void main(String [] args){
		int a=9;
		int b=18;
		boolean k=(a<b);
		System.out.println("value of boolean k:"+k);		
	}
}
