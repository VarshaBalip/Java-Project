package operator;

public class DefaultValueFloat {
	float f;

	public static void main(String[] args) {
		DefaultValueFloat r = new DefaultValueFloat();
		System.out.println(r.f);

	}

}
