package operator;

public class GreaterThanEquals {
	public static void main(String[] args) {
		int a = 300;
		int b = 200;
		boolean c = (a >= b);
		System.out.println(c);
	}

}
