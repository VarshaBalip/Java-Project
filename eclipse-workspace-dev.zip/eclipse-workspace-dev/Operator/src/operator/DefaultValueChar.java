package operator;

public class DefaultValueChar {
char c;
public static void main(String[] args){
	DefaultValueChar d= new DefaultValueChar();
	System.out.println(d.c);
	
	
} 
}