package operator;

public class LessThanEquals {
	public static void main(String[] args){
		int a=11;
		int b=11;
		boolean k=(a<=b);
		System.out.println("value of boolean k:"+k);
	}
}
