package operator;

public class DefaultValueInt {
	int i;

	public static void main(String[] args) {

		DefaultValueInt a = new DefaultValueInt();
		System.out.println(a.i);
	}

}
