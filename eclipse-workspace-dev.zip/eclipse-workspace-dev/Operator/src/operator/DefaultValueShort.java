package operator;

public class DefaultValueShort {
	short s;

	public static void main(String[] args) {

		DefaultValueShort t = new DefaultValueShort();
		System.out.println(t.s);
	}

}
