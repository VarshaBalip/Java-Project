package operator;

public class DefaultValueBoolean {
boolean b;
public static void main(String[]args){
	
	DefaultValueBoolean d= new DefaultValueBoolean();
	System.out.println(d.b);
	
}
} 
