package operator;

public class Demo {
	public static void main(String[] args) {
		int a=10;
		int b=20;
		int c=30;
		int d=40;
		String s="Varsha";
		System.out.println(a+b+s);
		System.out.println(a+b+s+c*d);
		System.out.println(a+b+s+d/c);
		System.out.println(a+b+s+(d-c));
		System.out.println(a+b+s+c+d);
	}

}
