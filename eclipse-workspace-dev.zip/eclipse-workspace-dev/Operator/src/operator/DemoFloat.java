package operator;

public class DemoFloat {

	public static void main(String[] args) {
		float f=12.569564256f;
		System.out.println(f);
	}

}
