package operator;

public class LessThan1 {
	public static void main(String[] args) {
		int a = 60;
		int b = 50;
		boolean c = (a < b);
		System.out.println("value of boolean c:"+c);
	}
}
